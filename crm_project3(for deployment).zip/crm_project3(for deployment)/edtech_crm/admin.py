from django.contrib import admin
from django.utils.html import format_html
from django.contrib.admin import AdminSite
from .models import UniversityLead, UniversityContact, UniversityAccount, UniversityOpportunity

class UniversityCRMAdminSite(AdminSite):
    def index(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context.update({
            'total_leads': UniversityLead.objects.count(),
            'total_contacts': UniversityContact.objects.count(),
            'total_accounts': UniversityAccount.objects.count(),
            'total_opportunities': UniversityOpportunity.objects.count(),
            'recent_leads': UniversityLead.objects.order_by('-created_at')[:5],
            'recent_opportunities': UniversityOpportunity.objects.order_by('-created_at')[:5],
        })
        return super().index(request, extra_context=extra_context)

admin_site = UniversityCRMAdminSite(name='university_crm')

@admin.register(UniversityLead)
class UniversityLeadAdmin(admin.ModelAdmin):
    list_display = ('get_full_name', 'university_name', 'title', 'lead_status', 'lead_owner', 'email', 'phone', 'created_at')
    list_filter = ('lead_status', 'lead_source', 'created_at')
    search_fields = ('first_name', 'last_name', 'university_name', 'email', 'phone')
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)
    
    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    get_full_name.short_description = 'Name'

@admin.register(UniversityContact)
class UniversityContactAdmin(admin.ModelAdmin):
    list_display = ('get_full_name', 'university_name', 'title', 'contact_owner', 'email', 'phone', 'created_at')
    list_filter = ('university_name', 'mailing_country', 'created_at')
    search_fields = ('first_name', 'last_name', 'university_name', 'email', 'phone')
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)
    
    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    get_full_name.short_description = 'Name'

@admin.register(UniversityAccount)
class UniversityAccountAdmin(admin.ModelAdmin):
    list_display = ('account_name', 'type', 'account_owner', 'website', 'created_at')
    list_filter = ('type', 'billing_country', 'created_at')
    search_fields = ('account_name', 'website')
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)

@admin.register(UniversityOpportunity)
class UniversityOpportunityAdmin(admin.ModelAdmin):
    list_display = ('opportunity_name', 'university_name', 'stage', 'amount', 'probability', 'opportunity_owner', 'created_at')
    list_filter = ('stage', 'forecast_category', 'created_at')
    search_fields = ('opportunity_name', 'university_name', 'description')
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)
    
    def amount(self, obj):
        if obj.amount:
            return format_html('<span style="color: green;">${:,.2f}</span>', float(obj.amount))
        return '-'
    amount.short_description = 'Amount'

# Customize the admin site
admin_site.site_header = 'University CRM Administration'
admin_site.site_title = 'University CRM Admin Portal'
admin_site.index_title = 'Welcome to University CRM Portal' 