from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q
from django.core.exceptions import ValidationError

class LocationBasedOwnerMixin:
    """Mixin to handle location-based owner assignment"""
    
    def get_location_fields(self):
        """Get the location fields specific to this model"""
        raise NotImplementedError("Subclasses must implement get_location_fields()")
    
    def get_owner_field(self):
        """Get the owner field name specific to this model"""
        raise NotImplementedError("Subclasses must implement get_owner_field()")
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy"""
        assigned = False
        location_fields = self.get_location_fields()
        owner_field = self.get_owner_field()
        
        # Define location combinations and their corresponding roles
        location_combinations = [
            # Full location (zone + state + city)
            {
                'condition': lambda: all(location_fields.values()),
                'role': 'city_head',
                'fields': location_fields
            },
            # Zone + State
            {
                'condition': lambda: location_fields['zone'] and location_fields['state'],
                'role': 'state_head',
                'fields': {k: v for k, v in location_fields.items() if k in ['zone', 'state']}
            },
            # Zone only
            {
                'condition': lambda: location_fields['zone'],
                'role': 'zonal_head',
                'fields': {'zone': location_fields['zone']}
            },
            # Zone only (fallback to regional head)
            {
                'condition': lambda: location_fields['zone'],
                'role': 'regional_head',
                'fields': {'zone': location_fields['zone']}
            }
        ]
        
        # Try each combination in order of specificity
        for combination in location_combinations:
            if combination['condition']():
                # Build the query dynamically based on available fields
                query = Q(is_active=True, role__name=combination['role'])
                for field, value in combination['fields'].items():
                    query &= Q(**{f"{field}__iexact": value})
                
                user_role = UserRole.objects.filter(query).first()
                
                if user_role:
                    setattr(self, owner_field, user_role.user)
                    assigned = True
                    break  # Stop after finding the first matching role
        
        # Save the update if an owner was assigned
        if assigned:
            self.save(update_fields=[owner_field])

ZONE_CHOICES = [
    ('None', 'None'),
    ('North', 'North'),
    ('South', 'South'),
    ('East', 'East'),
    ('West', 'West'),
]

LEAD_STATUS_CHOICES = [
    ('New', 'New'),
    ('Contacted', 'Contacted'),
    ('Nurturing', 'Nurturing'),
    ('Qualified', 'Qualified'),
    ('Unqualified', 'Unqualified'),
]

STUDENT_STATUS_CHOICES = [
    ('prospect', 'Prospect'),
    ('lead', 'Lead'),
    ('customer', 'Customer'),
    ('closed', 'Closed'),
]

GENDER_CHOICES = [
    ('male', 'Male'),
    ('female', 'Female'),
    ('others', 'Others'),
]

INDUSTRY_CHOICES = [
    ('student', 'Student'),
    ('education', 'Education'),
    ('technology', 'Technology'),
    ('healthcare', 'Healthcare'),
    ('finance', 'Finance'),
    ('manufacturing', 'Manufacturing'),
    ('retail', 'Retail'),
    ('consulting', 'Consulting'),
    ('media', 'Media & Entertainment'),
    ('hospitality', 'Hospitality'),
    ('other', 'Other')
]

ROLE_CHOICES = [
    ('super_admin', 'Super Admin'),
    ('regional_head', 'Regional Head'),
    ('zonal_head', 'Zonal Head'),
    ('state_head', 'State Head'),
    ('city_head', 'City Head'),
    ('team_leader', 'Team Leader'),
    ('sales_executive', 'Sales Executive'),
]

NOTIFICATION_TYPES = [
    ('student_assignment', 'Student Assignment'),
    ('student_reassignment', 'Student Reassignment'),
    ('assignment_failed', 'Assignment Failed'),
    ('general', 'General Notification')
]

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=50, choices=NOTIFICATION_TYPES, default='general')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.title} - {self.user.username}"
    
    class Meta:
        ordering = ['-created_at']

STATE_CHOICES = [
    ('Andaman & Nicobar Islands', 'Andaman & Nicobar Islands'),
    ('Andhra Pradesh', 'Andhra Pradesh'),
    ('Arunachal Pradesh', 'Arunachal Pradesh'),
    ('Assam', 'Assam'),
    ('Bihar', 'Bihar'),
    ('Chandigarh', 'Chandigarh'),
    ('Chhattisgarh', 'Chhattisgarh'),
    ('Dadra & Nagar Haveli', 'Dadra & Nagar Haveli'),
    ('Delhi', 'Delhi'),
    ('Goa', 'Goa'),
    ('Gujarat', 'Gujarat'),
    ('Haryana', 'Haryana'),
    ('Himachal Pradesh', 'Himachal Pradesh'),
    ('Jammu & Kashmir', 'Jammu & Kashmir'),
    ('Jharkhand', 'Jharkhand'),
    ('Karnataka', 'Karnataka'),
    ('Kerala', 'Kerala'),
    ('Madhya Pradesh', 'Madhya Pradesh'),
    ('Maharashtra', 'Maharashtra'),
    ('Manipur', 'Manipur'),
    ('Meghalaya', 'Meghalaya'),
    ('Mizoram', 'Mizoram'),
    ('Nagaland', 'Nagaland'),
    ('Odisha', 'Odisha'),
    ('Puducherry', 'Puducherry'),
    ('Punjab', 'Punjab'),
    ('Rajasthan', 'Rajasthan'),
    ('Tamil Nadu', 'Tamil Nadu'),
    ('Telangana', 'Telangana'),
    ('Tripura', 'Tripura'),
    ('Uttar Pradesh', 'Uttar Pradesh'),
    ('Uttarakhand', 'Uttarakhand'),
    ('West Bengal', 'West Bengal'),
]

class UniversityLead(LocationBasedOwnerMixin, models.Model):
    # Lead Source Choices
    LEAD_SOURCE_CHOICES = [
        ('None', 'None'),
        ('Advertisement', 'Advertisement'),
        ('EmployeeReferral', 'Employee Referral'),
        ('ExternalReferral', 'External Referral'),
        ('Partner', 'Partner'),
        ('PublicRelations', 'Public Relations'),
        ('SeminarInternal', 'Seminar - Internal'),
        ('SeminarPartner', 'Seminar - Partner'),
        ('TradeShow', 'Trade Show'),
        ('Web', 'Web'),
        ('WordOfMouth', 'Word of mouth'),
        ('Other', 'Other'),
    ]
    
    # Basic Information
    id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    university_name = models.CharField(max_length=200)
    title = models.CharField(max_length=100)
    website = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    
    # Lead Status and Ownership
    lead_status = models.CharField(max_length=20, choices=LEAD_STATUS_CHOICES, default='New')
    lead_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_leads')
    
    # Contact Information
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    street = models.CharField(max_length=200, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    zipcode = models.CharField(max_length=20, blank=True, null=True)
    state = models.CharField(max_length=100, choices=STATE_CHOICES, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    
    # University Details
    no_of_students = models.IntegerField(blank=True, null=True)
    annual_revenue = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    
    # Lead Source
    lead_source = models.CharField(max_length=20, choices=LEAD_SOURCE_CHOICES, default='None')
    
    # Industry
    industry = models.CharField(max_length=100, blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # User association
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='leads')
    
    # Zone
    zone = models.CharField(max_length=10, choices=ZONE_CHOICES, default='None')
    
    # Next Step and Meeting Schedule
    next_step = models.TextField(blank=True)
    meeting_schedule = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.university_name}"
    
    def get_location_fields(self):
        """Get the location fields for this model"""
        return {
            'zone': self.zone,
            'state': self.state,
            'city': self.city
        }
    
    def get_owner_field(self):
        """Get the owner field name for this model"""
        return 'lead_owner'
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        create_related_records = False
        
        # If record exists, check for field changes that would affect hierarchy
        if not is_new:
            original = UniversityLead.objects.get(pk=self.pk)
            
            # Check if any location field has changed
            location_fields_changed = (
                original.city != self.city or 
                original.state != self.state or 
                original.zone != self.zone
            )
            
            if location_fields_changed:
                field_changed = True

            # Check if lead status changed to Qualified
            if original.lead_status != 'Qualified' and self.lead_status == 'Qualified':
                create_related_records = True
        
        # Save the lead first
        super().save(*args, **kwargs)
        
        # Determine when to reassign - for new records or when relevant fields change
        if is_new or field_changed:
            self.assign_owner_by_location()

        # Create related records when lead becomes qualified
        if create_related_records:
            # Create Account
            account = UniversityAccount.objects.create(
                account_name=self.university_name,
                website=self.website,
                type='Prospect',
                description=self.description,
                billing_street=self.street,
                billing_city=self.city,
                billing_state=self.state,
                billing_zipcode=self.zipcode,
                billing_country=self.country,
                shipping_street=self.street,
                shipping_city=self.city,
                shipping_state=self.state,
                shipping_zipcode=self.zipcode,
                shipping_country=self.country,
                zone=self.zone,
                account_owner=self.lead_owner,
                user=self.user
            )

            # Create Contact
            contact = UniversityContact.objects.create(
                first_name=self.first_name,
                last_name=self.last_name,
                university_name=self.university_name,
                title=self.title,
                description=self.description,
                phone=self.phone,
                email=self.email,
                mailing_street=self.street,
                mailing_city=self.city,
                mailing_state=self.state,
                mailing_zipcode=self.zipcode,
                mailing_country=self.country,
                zone=self.zone,
                contact_owner=self.lead_owner,
                user=self.user
            )

            # Create Opportunity
            opportunity = UniversityOpportunity.objects.create(
                opportunity_name=f"{self.university_name} - Initial Opportunity",
                university_name=self.university_name,
                description=self.description,
                stage='Qualify',
                probability=20,
                forecast_category='Pipeline',
                opportunity_owner=self.lead_owner,
                lead=self,
                zone=self.zone,
                user=self.user
            )


class UniversityContact(LocationBasedOwnerMixin, models.Model):
    # Basic Information
    id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    university_name = models.CharField(max_length=200)
    title = models.CharField(max_length=100)
    reports_to = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True)
    description = models.TextField(blank=True, null=True)
    contact_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_contacts')
    
    # Contact Information
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    
    # Mailing Address
    mailing_street = models.CharField(max_length=200, blank=True, null=True)
    mailing_city = models.CharField(max_length=100, blank=True, null=True)
    mailing_zipcode = models.CharField(max_length=20, blank=True, null=True)
    mailing_state = models.CharField(max_length=100, choices=STATE_CHOICES, blank=True, null=True)
    mailing_country = models.CharField(max_length=100, blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # User association
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='contacts')
    
    # Zone
    zone = models.CharField(max_length=10, choices=ZONE_CHOICES, default='None')
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.university_name}"
    
    def get_location_fields(self):
        """Get the location fields for this model"""
        return {
            'zone': self.zone,
            'state': self.mailing_state,
            'city': self.mailing_city
        }
    
    def get_owner_field(self):
        """Get the owner field name for this model"""
        return 'contact_owner'
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        
        # If record exists, check for field changes that would affect hierarchy
        if not is_new:
            original = UniversityContact.objects.get(pk=self.pk)
            
            # Check if any location field has changed
            location_fields_changed = (
                original.mailing_city != self.mailing_city or 
                original.mailing_state != self.mailing_state or 
                original.zone != self.zone
            )
            
            if location_fields_changed:
                # Case 1: All three fields were present and any one changed
                if original.mailing_city and original.mailing_state and original.zone:
                    field_changed = True
                
                # Case 2: City was added to a record that had zone and state
                elif not original.mailing_city and self.mailing_city and original.mailing_state and original.zone:
                    field_changed = True
                
                # Case 3: City was removed from a record that had all three fields
                elif original.mailing_city and not self.mailing_city and original.mailing_state and original.zone:
                    field_changed = True
                
                # Case 4: State was added to a record that had just zone
                elif not original.mailing_state and self.mailing_state and original.zone:
                    field_changed = True
                
                # Case 5: State was removed from a record that had all fields
                elif original.mailing_state and not self.mailing_state and original.mailing_city and original.zone:
                    field_changed = True
                
                # Case 6: Zone was added to a record that had state and city
                elif not original.zone and self.zone and original.mailing_state and original.mailing_city:
                    field_changed = True
                
                # Case 7: Zone was removed from a record that had all fields
                elif original.zone and not self.zone and original.mailing_state and original.mailing_city:
                    field_changed = True
                
                # Case 8: Any combination of fields changed while maintaining hierarchy
                elif (self.mailing_city and self.mailing_state and self.zone) and \
                     (original.mailing_city or self.mailing_city) and \
                     (original.mailing_state or self.mailing_state) and \
                     (original.zone or self.zone):
                    field_changed = True
        
        # Save the contact first
        super().save(*args, **kwargs)
        
        # Determine when to reassign - for new records or when relevant fields change
        if is_new or field_changed:
            self.assign_owner_by_location()
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy"""
        assigned = False
        
        # Define location combinations and their corresponding roles
        location_combinations = [
            # Full location (zone + state + city)
            {
                'condition': lambda: self.zone and self.mailing_state and self.mailing_city,
                'role': 'city_head',
                'fields': {'city': self.mailing_city, 'state': self.mailing_state, 'zone': self.zone}
            },
            # Zone + State
            {
                'condition': lambda: self.zone and self.mailing_state,
                'role': 'state_head',
                'fields': {'state': self.mailing_state, 'zone': self.zone}
            },
            # Zone only
            {
                'condition': lambda: self.zone,
                'role': 'zonal_head',
                'fields': {'zone': self.zone}
            },
            # Zone only (fallback to regional head)
            {
                'condition': lambda: self.zone,
                'role': 'regional_head',
                'fields': {'zone': self.zone}
            }
        ]
        
        # Try each combination in order of specificity
        for combination in location_combinations:
            if combination['condition']():
                # Build the query dynamically based on available fields
                query = Q(is_active=True, role__name=combination['role'])
                for field, value in combination['fields'].items():
                    query &= Q(**{f"{field}__iexact": value})
                
                user_role = UserRole.objects.filter(query).first()
                
                if user_role:
                    self.contact_owner = user_role.user
                    assigned = True
                    break  # Stop after finding the first matching role
        
        # Save the update if an owner was assigned
        if assigned:
            UniversityContact.objects.filter(pk=self.pk).update(contact_owner=self.contact_owner)


class UniversityAccount(LocationBasedOwnerMixin, models.Model):
    # Account Type Choices
    ACCOUNT_TYPE_CHOICES = [
        ('Analyst', 'Analyst'),
        ('Competitor', 'Competitor'),
        ('Customer', 'Customer'),
        ('Integrator', 'Integrator'),
        ('Investor', 'Investor'),
        ('Partner', 'Partner'),
        ('Press', 'Press'),
        ('Prospect', 'Prospect'),
        ('Reseller', 'Reseller'),
        ('Other', 'Other'),
    ]
    
    # Basic Information
    id = models.AutoField(primary_key=True)
    account_name = models.CharField(max_length=200)
    website = models.URLField(blank=True, null=True)
    type = models.CharField(max_length=20, choices=ACCOUNT_TYPE_CHOICES, default='Prospect')
    description = models.TextField(blank=True, null=True)
    parent_account = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True)
    account_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_accounts')
    
    # Billing Address
    billing_street = models.CharField(max_length=200, blank=True, null=True)
    billing_city = models.CharField(max_length=100, blank=True, null=True)
    billing_state = models.CharField(max_length=100, choices=STATE_CHOICES, blank=True, null=True)
    billing_zipcode = models.CharField(max_length=20, blank=True, null=True)
    billing_country = models.CharField(max_length=100, blank=True, null=True)
    
    # Shipping Address
    shipping_street = models.CharField(max_length=200, blank=True, null=True)
    shipping_city = models.CharField(max_length=100, blank=True, null=True)
    shipping_state = models.CharField(max_length=100, choices=STATE_CHOICES, blank=True, null=True)
    shipping_zipcode = models.CharField(max_length=20, blank=True, null=True)
    shipping_country = models.CharField(max_length=100, blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # User association
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='accounts')
    
    # Zone
    zone = models.CharField(max_length=10, choices=ZONE_CHOICES, default='None')
    
    def __str__(self):
        return self.account_name
    
    def get_location_fields(self):
        """Get the location fields for this model"""
        return {
            'zone': self.zone,
            'state': self.billing_state,
            'city': self.billing_city
        }
    
    def get_owner_field(self):
        """Get the owner field name for this model"""
        return 'account_owner'
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        
        # If record exists, check for field changes that would affect hierarchy
        if not is_new:
            original = UniversityAccount.objects.get(pk=self.pk)
            
            # Check if location fields have changed in a way that would affect assignment
            # Case: City was added to a record that had zone and state
            if not original.billing_city and self.billing_city and original.billing_state and original.zone:
                field_changed = True
            # Case: City was removed from a record that had all three fields
            elif original.billing_city and not self.billing_city and original.billing_state and original.zone:
                field_changed = True
            # Case: State was added to a record that had just zone
            elif not original.billing_state and self.billing_state and original.zone:
                field_changed = True
            # Check any location field changes if already has all 3 fields
            elif original.billing_city != self.billing_city or original.billing_state != self.billing_state or original.zone != self.zone:
                # Only consider meaningful changes (not changes to/from None or empty string)
                if (self.billing_city and self.billing_state and self.zone) and (original.billing_city or self.billing_city) and (original.billing_state or self.billing_state) and (original.zone or self.zone):
                    field_changed = True
        
        # Save the account first
        super().save(*args, **kwargs)
        
        # Determine when to reassign - for new records or when relevant fields change
        if is_new or field_changed:
            self.assign_owner_by_location()
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy"""
        assigned = False
        
        # Case 1: If all three fields (zone, state, city) are provided, look for City Head
        if self.zone and self.billing_state and self.billing_city:
            user_role = UserRole.objects.filter(
                city__iexact=self.billing_city,
                state__iexact=self.billing_state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='city_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
        
        # Case 2: If only zone and state are provided, look for State Head
        elif self.zone and self.billing_state:
            user_role = UserRole.objects.filter(
                state__iexact=self.billing_state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='state_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
        
        # Case 3: If only zone is provided, look for Zonal Head
        elif self.zone:
            user_role = UserRole.objects.filter(
                zone__iexact=self.zone,
                is_active=True,
                role__name='zonal_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
            # If no Zonal Head found, try Regional Head
            if not assigned:
                user_role = UserRole.objects.filter(
                    zone__iexact=self.zone,
                    is_active=True,
                    role__name='regional_head'
                ).first()
                
                if user_role:
                    self.account_owner = user_role.user
                    assigned = True
        
        # Save the update if an owner was assigned
        if assigned:
            UniversityAccount.objects.filter(pk=self.pk).update(account_owner=self.account_owner)


class UniversityOpportunity(models.Model):
    # Stage Choices
    STAGE_CHOICES = [
        ('Qualify', 'Qualify'),
        ('Meet & Present', 'Meet & Present'),
        ('Propose', 'Propose'),
        ('Negotiate', 'Negotiate'),
        ('Closed Won', 'Closed Won'),
        ('Closed Lost', 'Closed Lost'),
    ]
    
    # Forecast Category Choices
    FORECAST_CATEGORY_CHOICES = [
        ('Pipeline', 'Pipeline'),
        ('Best Case', 'Best Case'),
        ('Commit', 'Commit'),
        ('Closed', 'Closed'),
    ]
    
    # Basic Information
    id = models.AutoField(primary_key=True)
    opportunity_name = models.CharField(max_length=200)
    university_name = models.CharField(max_length=200)
    open_date = models.DateField(auto_now_add=True)
    closed_date = models.DateField(blank=True, null=True)
    amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    opportunity_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_opportunities')
    
    # Opportunity Stage and Probability
    stage = models.CharField(max_length=20, choices=STAGE_CHOICES, default='Qualify')
    probability = models.IntegerField(default=0)
    forecast_category = models.CharField(max_length=20, choices=FORECAST_CATEGORY_CHOICES, default='Pipeline')
    next_step = models.CharField(max_length=200, blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Lead association
    lead = models.ForeignKey(UniversityLead, on_delete=models.CASCADE, related_name='opportunities', null=True)
    
    # User association
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='opportunities')
    
    # Zone
    zone = models.CharField(max_length=10, choices=ZONE_CHOICES, default='None')
    
    def __str__(self):
        return self.opportunity_name
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        lead_city_added = False
        lead_location_changed = False
        
        # If record exists, check for lead-related field changes
        if not is_new and self.lead:
            try:
                original = UniversityOpportunity.objects.get(pk=self.pk)
                original_lead = original.lead
                
                # Check if lead association changed
                if original_lead != self.lead:
                    field_changed = True
                # Check if the lead's location info was added or changed after opportunity creation
                elif original_lead and self.lead:
                    # City was added
                    if not original_lead.city and self.lead.city:
                        lead_city_added = True
                    # State was added
                    elif not original_lead.state and self.lead.state:
                        lead_location_changed = True
                    # Zone was added/changed
                    elif original_lead.zone != self.lead.zone and self.lead.zone:
                        lead_location_changed = True
                    # Any lead location field changed
                    elif (original_lead.city != self.lead.city or 
                          original_lead.state != self.lead.state or 
                          original_lead.zone != self.lead.zone):
                        if self.lead.city and self.lead.state and self.lead.zone:
                            lead_location_changed = True
            except Exception:
                pass  # Handle case where original or lead might not exist
            
        # Check if zone changed when no lead is available
        if not is_new and not self.lead:
            try:
                original = UniversityOpportunity.objects.get(pk=self.pk)
                if original.zone != self.zone and self.zone and self.zone != 'None':
                    field_changed = True
            except Exception:
                pass
        
        # Save the opportunity first
        super().save(*args, **kwargs)
        
        # Determine when to reassign - for any condition that indicates location hierarchy changed
        if is_new or field_changed or lead_city_added or lead_location_changed:
            self.assign_owner_by_location()
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy using lead location if available"""
        assigned = False
        
        # First attempt using lead's location
        if self.lead:
            # Case 1: If all three fields (zone, state, city) are provided, look for City Head
            if self.lead.zone and self.lead.state and self.lead.city:
                user_role = UserRole.objects.filter(
                    city__iexact=self.lead.city,
                    state__iexact=self.lead.state,
                    zone__iexact=self.lead.zone,
                    is_active=True,
                    role__name='city_head'
                ).first()
                
                if user_role:
                    self.opportunity_owner = user_role.user
                    assigned = True
            
            # Case 2: If only zone and state are provided, look for State Head
            elif self.lead.zone and self.lead.state:
                user_role = UserRole.objects.filter(
                    state__iexact=self.lead.state,
                    zone__iexact=self.lead.zone,
                    is_active=True,
                    role__name='state_head'
                ).first()
                
                if user_role:
                    self.opportunity_owner = user_role.user
                    assigned = True
            
            # Case 3: If only zone is provided, look for Zonal Head
            elif self.lead.zone:
                user_role = UserRole.objects.filter(
                    zone__iexact=self.lead.zone,
                    is_active=True,
                    role__name='zonal_head'
                ).first()
                
                if user_role:
                    self.opportunity_owner = user_role.user
                    assigned = True
                # If no Zonal Head found, try Regional Head
                if not assigned:
                    user_role = UserRole.objects.filter(
                        zone__iexact=self.lead.zone,
                        is_active=True,
                        role__name='regional_head'
                    ).first()
                    
                    if user_role:
                        self.opportunity_owner = user_role.user
                        assigned = True
        
        # If lead-based assignment failed, fall back to opportunity's own zone
        if not assigned and self.zone and self.zone != 'None':
            user_role = UserRole.objects.filter(
                zone__iexact=self.zone,
                is_active=True,
                role__name__in=['zonal_head', 'regional_head']
            ).first()
            
            if user_role:
                self.opportunity_owner = user_role.user
                assigned = True
        
        # Save the update if an owner was assigned
        if assigned:
            UniversityOpportunity.objects.filter(pk=self.pk).update(opportunity_owner=self.opportunity_owner)


class Student(LocationBasedOwnerMixin, models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20)
    date_of_birth = models.DateField()
    university = models.ForeignKey('UniversityAccount', on_delete=models.SET_NULL, null=True, blank=True)
    industry = models.CharField(max_length=50, choices=INDUSTRY_CHOICES, default='student')
    
    # Address fields
    street = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100, choices=STATE_CHOICES)
    zone = models.CharField(max_length=50, choices=ZONE_CHOICES)
    country = models.CharField(max_length=100)
    
    # Management fields
    student_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_students')
    status = models.CharField(max_length=20, choices=STUDENT_STATUS_CHOICES, default='prospect')
    description = models.TextField(blank=True)
    next_step = models.TextField(blank=True)
    meeting_schedule = models.DateTimeField(null=True, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
    def get_location_fields(self):
        """Get the location fields for this model"""
        return {
            'zone': self.zone,
            'state': self.state,
            'city': self.city
        }
    
    def get_owner_field(self):
        """Get the owner field name for this model"""
        return 'student_owner'

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        old_owner = None

        # If record exists, check for field changes that would affect hierarchy
        if not is_new:
            original = Student.objects.get(pk=self.pk)
            old_owner = original.student_owner
            
            # Check if any location field has changed
            if (original.city != self.city or 
                original.state != self.state or 
                original.zone != self.zone):
                field_changed = True
                
                # Log the changes
                changes = []
                if original.city != self.city:
                    changes.append(f"City: {original.city} → {self.city}")
                if original.state != self.state:
                    changes.append(f"State: {original.state} → {self.state}")
                if original.zone != self.zone:
                    changes.append(f"Zone: {original.zone} → {self.zone}")
                
                if changes:
                    print(f"Location changes for student {self.first_name} {self.last_name}: {', '.join(changes)}")

        # Validate location field combinations
        if self.city and not self.state:
            raise ValidationError("State is required when city is provided")
        if self.state and not self.zone:
            raise ValidationError("Zone is required when state is provided")
        if self.zone == 'None' and (self.state or self.city):
            raise ValidationError("Cannot assign state or city when zone is 'None'")

        # Save the student first
        super().save(*args, **kwargs)
        
        # Create student account if status changed to customer
        if self.status == 'customer':
            StudentAccount.objects.get_or_create(
                student=self,
                defaults={
                    'account_name': f"{self.first_name} {self.last_name}",
                    'industry': self.industry,
                    'description': self.description,
                    'street': self.street,
                    'city': self.city,
                    'state': self.state,
                    'zone': self.zone,
                    'country': self.country,
                    'payment_amount': 0,  # Default value, to be updated later
                    'payment_mode': 'full',  # Default value
                    'enrollment_date': timezone.now().date(),
                    'completion_date': (timezone.now() + timezone.timedelta(days=365)).date(),  # Default 1 year
                    'account_owner': self.student_owner,
                    'status': self.status
                }
            )
        
        # Determine when to reassign owner - for new records or when relevant fields change
        if is_new or field_changed:
            self.assign_owner_by_location()
            
            # If owner has changed, log it and send notification
            if old_owner != self.student_owner:
                print(f"Owner changed for student {self.first_name} {self.last_name}: "
                      f"{old_owner.username if old_owner else 'None'} → "
                      f"{self.student_owner.username if self.student_owner else 'None'}")
                
                # Send notification to new owner
                if self.student_owner:
                    Notification.objects.create(
                        user=self.student_owner,
                        title="New Student Assignment",
                        message=f"You have been assigned as the owner of student: {self.first_name} {self.last_name}",
                        notification_type="student_assignment"
                    )
                
                # Send notification to old owner
                if old_owner:
                    Notification.objects.create(
                        user=old_owner,
                        title="Student Reassignment",
                        message=f"Student {self.first_name} {self.last_name} has been reassigned to {self.student_owner.username if self.student_owner else 'no one'}",
                        notification_type="student_reassignment"
                    )
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy with improved logging"""
        assigned = False
        previous_owner = self.student_owner
        assignment_log = []
        
        # Case 1: If all three fields (zone, state, city) are provided, look for City Head
        if self.zone and self.state and self.city:
            assignment_log.append(f"Searching for City Head in {self.city}, {self.state}, {self.zone}...")
            user_role = UserRole.objects.filter(
                city__iexact=self.city,
                state__iexact=self.state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='city_head'
            ).first()
            
            if user_role:
                self.student_owner = user_role.user
                assigned = True
                assignment_log.append(f"Found City Head: {user_role.user.username}")
            else:
                assignment_log.append("No City Head found, trying State Head...")
        
        # Case 2: If only zone and state are provided, look for State Head
        if not assigned and self.zone and self.state:
            assignment_log.append(f"Searching for State Head in {self.state}, {self.zone}...")
            user_role = UserRole.objects.filter(
                state__iexact=self.state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='state_head'
            ).first()
            
            if user_role:
                self.student_owner = user_role.user
                assigned = True
                assignment_log.append(f"Found State Head: {user_role.user.username}")
            else:
                assignment_log.append("No State Head found, trying Zonal Head...")
        
        # Case 3: If only zone is provided, look for Zonal Head
        if not assigned and self.zone:
            assignment_log.append(f"Searching for Zonal Head in {self.zone}...")
            user_role = UserRole.objects.filter(
                zone__iexact=self.zone,
                is_active=True,
                role__name='zonal_head'
            ).first()
            
            if user_role:
                self.student_owner = user_role.user
                assigned = True
                assignment_log.append(f"Found Zonal Head: {user_role.user.username}")
            else:
                assignment_log.append("No Zonal Head found, trying Regional Head...")
                # If no Zonal Head found, try Regional Head
                user_role = UserRole.objects.filter(
                    zone__iexact=self.zone,
                    is_active=True,
                    role__name='regional_head'
                ).first()
                
                if user_role:
                    self.student_owner = user_role.user
                    assigned = True
                    assignment_log.append(f"Found Regional Head: {user_role.user.username}")
                else:
                    assignment_log.append("No Regional Head found")
        
        # Log the assignment process
        print(f"\nOwner assignment process for student {self.first_name} {self.last_name}:")
        print("\n".join(assignment_log))
        
        if not assigned:
            print("Warning: No suitable owner found based on location hierarchy")
            # Create a notification for super admin
            superusers = User.objects.filter(is_superuser=True)
            for superuser in superusers:
                Notification.objects.create(
                    user=superuser,
                    title="No Owner Assignment",
                    message=f"Could not find suitable owner for student: {self.first_name} {self.last_name} "
                           f"(Zone: {self.zone}, State: {self.state}, City: {self.city})",
                    notification_type="assignment_failed"
                )
        
        # Save the update if an owner was assigned
        if assigned:
            # Use update to avoid triggering save() again
            Student.objects.filter(pk=self.pk).update(student_owner=self.student_owner)
            
            # Log the final assignment
            if previous_owner != self.student_owner:
                print(f"Owner changed from {previous_owner.username if previous_owner else 'None'} "
                      f"to {self.student_owner.username}")
                
                # Send notification to new owner
                if self.student_owner:
                    Notification.objects.create(
                        user=self.student_owner,
                        title="New Student Assignment",
                        message=f"You have been assigned as the owner of student: {self.first_name} {self.last_name}",
                        notification_type="student_assignment"
                    )
                
                # Send notification to old owner
                if previous_owner:
                    Notification.objects.create(
                        user=previous_owner,
                        title="Student Reassignment",
                        message=f"Student {self.first_name} {self.last_name} has been reassigned to {self.student_owner.username if self.student_owner else 'no one'}",
                        notification_type="student_reassignment"
                    )

    class Meta:
        ordering = ['-created_at']


PAYMENT_MODE_CHOICES = [
    ('full', 'Full Payment'),
    ('emi', 'EMI')
]

class StudentAccount(LocationBasedOwnerMixin, models.Model):
    # Basic Information
    student = models.OneToOneField(Student, on_delete=models.CASCADE, related_name='account')
    account_name = models.CharField(max_length=200)  # Will be student's full name
    industry = models.CharField(max_length=50, choices=INDUSTRY_CHOICES)
    description = models.TextField(blank=True)
    
    # Address Information (copied from student)
    street = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100, choices=STATE_CHOICES)
    zone = models.CharField(max_length=50, choices=ZONE_CHOICES)
    country = models.CharField(max_length=100)
    
    # Payment Information
    payment_amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_mode = models.CharField(max_length=10, choices=PAYMENT_MODE_CHOICES, default='full')
    emi_months = models.PositiveIntegerField(null=True, blank=True)  # Only if payment_mode is 'emi'
    monthly_payment = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    # Duration
    enrollment_date = models.DateField()
    completion_date = models.DateField()
    
    # Management
    account_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='owned_student_accounts')
    status = models.CharField(max_length=20, choices=STUDENT_STATUS_CHOICES, default='prospect')
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.account_name
    
    def get_location_fields(self):
        """Get the location fields for this model"""
        return {
            'zone': self.zone,
            'state': self.state,
            'city': self.city
        }
    
    def get_owner_field(self):
        """Get the owner field name for this model"""
        return 'account_owner'

    def get_enrollment_progress(self):
        today = timezone.now().date()
        
        # If not started yet
        if today < self.enrollment_date:
            return 0
        # If completed
        if today > self.completion_date:
            return 100
            
        # Calculate progress
        total_days = (self.completion_date - self.enrollment_date).days
        elapsed_days = (today - self.enrollment_date).days
        progress = (elapsed_days / total_days) * 100
        return min(round(progress), 100)

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        field_changed = False
        
        # If record exists, check for field changes that would affect hierarchy
        if not is_new:
            original = StudentAccount.objects.get(pk=self.pk)
            
            # Check if location fields have changed in a way that would affect assignment
            # Case: City was added to a record that had zone and state
            if not original.city and self.city and original.state and original.zone:
                field_changed = True
            # Case: City was removed from a record that had all three fields
            elif original.city and not self.city and original.state and original.zone:
                field_changed = True
            # Case: State was added to a record that had just zone
            elif not original.state and self.state and original.zone:
                field_changed = True
            # Check any location field changes if already has all 3 fields
            elif original.city != self.city or original.state != self.state or original.zone != self.zone:
                # Only consider meaningful changes (not changes to/from None or empty string)
                if (self.city and self.state and self.zone) and (original.city or self.city) and (original.state or self.state) and (original.zone or self.zone):
                    field_changed = True
        
        # Auto-populate account name from student's full name
        if self.student:
            self.account_name = f"{self.student.first_name} {self.student.last_name}"
            self.industry = self.student.industry
            
        # Calculate monthly payment for EMI
        if self.payment_mode == 'emi' and self.emi_months:
            self.monthly_payment = self.payment_amount / self.emi_months
            
        # Save the account first
        super().save(*args, **kwargs)
        
        # Determine when to reassign - for new records or when relevant fields change
        if is_new or field_changed:
            self.assign_owner_by_location()
    
    def assign_owner_by_location(self):
        """Assign owner based on location hierarchy"""
        assigned = False
        
        # Case 1: If all three fields (zone, state, city) are provided, look for City Head
        if self.zone and self.state and self.city:
            user_role = UserRole.objects.filter(
                city__iexact=self.city,
                state__iexact=self.state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='city_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
        
        # Case 2: If only zone and state are provided, look for State Head
        elif self.zone and self.state:
            user_role = UserRole.objects.filter(
                state__iexact=self.state,
                zone__iexact=self.zone,
                is_active=True,
                role__name='state_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
        
        # Case 3: If only zone is provided, look for Zonal Head
        elif self.zone:
            user_role = UserRole.objects.filter(
                zone__iexact=self.zone,
                is_active=True,
                role__name='zonal_head'
            ).first()
            
            if user_role:
                self.account_owner = user_role.user
                assigned = True
            # If no Zonal Head found, try Regional Head
            if not assigned:
                user_role = UserRole.objects.filter(
                    zone__iexact=self.zone,
                    is_active=True,
                    role__name='regional_head'
                ).first()
                
                if user_role:
                    self.account_owner = user_role.user
                    assigned = True
        
        # Save the update if an owner was assigned
        if assigned:
            StudentAccount.objects.filter(pk=self.pk).update(account_owner=self.account_owner)

    class Meta:
        ordering = ['-created_at']


class Role(models.Model):
    name = models.CharField(max_length=50, choices=ROLE_CHOICES)
    parent_role = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='child_roles')
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.get_name_display()

    class Meta:
        ordering = ['name']

class UserRole(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_roles')
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    zone = models.CharField(max_length=10, choices=ZONE_CHOICES, null=True, blank=True)
    state = models.CharField(max_length=100, choices=STATE_CHOICES, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)  # Can be handled as multiple cities via the view
    is_active = models.BooleanField(default=True)
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='role_assignments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['user', 'role', 'zone', 'state', 'city']
        ordering = ['role', 'zone', 'state', 'city']

    def __str__(self):
        location = []
        if self.zone:
            location.append(f"Zone: {self.get_zone_display()}")
        if self.state:
            location.append(f"State: {self.state}")
        if self.city:
            location.append(f"City: {self.city}")
        location_str = " | ".join(location) if location else "Global"
        return f"{self.user.get_full_name()} - {self.role.get_name_display()} ({location_str})"

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        super().save(*args, **kwargs)
        
        if is_new and self.is_active:
            self.assign_entities()

    def assign_entities(self):
        """Automatically assign entities to the user based on their role and location"""
        # Get all users with roles that should report to this role
        subordinate_roles = Role.objects.filter(parent_role=self.role)
        subordinate_user_roles = UserRole.objects.filter(
            role__in=subordinate_roles,
            is_active=True
        )
        
        # Only proceed if we have appropriate role
        if self.role.name in ['regional_head', 'zonal_head', 'state_head', 'city_head']:
            # For leads
            lead_filter = Q()
            if self.city:
                lead_filter = Q(city__iexact=self.city)
            elif self.state:
                lead_filter = Q(state__iexact=self.state)
            elif self.zone:
                lead_filter = Q(zone__iexact=self.zone)
            
            if lead_filter:
                leads_to_update = UniversityLead.objects.filter(lead_filter)
                if self.role.name != 'regional_head':
                    leads_to_update = leads_to_update.filter(
                        Q(lead_owner__isnull=True) |
                        Q(lead_owner__user_roles__in=subordinate_user_roles)
                    )
                leads_to_update.update(lead_owner=self.user)

            # For contacts (uses mailing_* fields)
            contact_filter = Q()
            if self.city:
                contact_filter = Q(mailing_city__iexact=self.city)
            elif self.state:
                contact_filter = Q(mailing_state__iexact=self.state)
            elif self.zone:
                contact_filter = Q(zone__iexact=self.zone)
            
            if contact_filter:
                contacts_to_update = UniversityContact.objects.filter(contact_filter)
                if self.role.name != 'regional_head':
                    contacts_to_update = contacts_to_update.filter(
                        Q(contact_owner__isnull=True) |
                        Q(contact_owner__user_roles__in=subordinate_user_roles)
                    )
                contacts_to_update.update(contact_owner=self.user)

            # For accounts (uses billing_* fields)
            account_filter = Q()
            if self.city:
                account_filter = Q(billing_city__iexact=self.city)
            elif self.state:
                account_filter = Q(billing_state__iexact=self.state)
            elif self.zone:
                account_filter = Q(zone__iexact=self.zone)
            
            if account_filter:
                accounts_to_update = UniversityAccount.objects.filter(account_filter)
                if self.role.name != 'regional_head':
                    accounts_to_update = accounts_to_update.filter(
                        Q(account_owner__isnull=True) |
                        Q(account_owner__user_roles__in=subordinate_user_roles)
                    )
                accounts_to_update.update(account_owner=self.user)

            # For opportunities (uses lead's location)
            opp_filter = Q()
            if self.city:
                opp_filter = Q(lead__city__iexact=self.city)
            elif self.state:
                opp_filter = Q(lead__state__iexact=self.state)
            elif self.zone:
                opp_filter = Q(zone__iexact=self.zone)
            
            if opp_filter:
                opportunities_to_update = UniversityOpportunity.objects.filter(opp_filter)
                if self.role.name != 'regional_head':
                    opportunities_to_update = opportunities_to_update.filter(
                        Q(opportunity_owner__isnull=True) |
                        Q(opportunity_owner__user_roles__in=subordinate_user_roles)
                    )
                opportunities_to_update.update(opportunity_owner=self.user)

            # For students - Modified to handle zone head assignments properly
            student_filter = Q()
            if self.city:
                student_filter = Q(city__iexact=self.city)
            elif self.state:
                student_filter = Q(state__iexact=self.state)
            elif self.zone:
                student_filter = Q(zone__iexact=self.zone)
            
            if student_filter:
                students_to_update = Student.objects.filter(student_filter)
                if self.role.name != 'regional_head':
                    # For zone heads, only filter out students owned by city/state heads
                    if self.role.name == 'zonal_head':
                        students_to_update = students_to_update.filter(
                            Q(student_owner__isnull=True) |
                            Q(student_owner__user_roles__role__name__in=['regional_head'])
                        )
                    else:
                        students_to_update = students_to_update.filter(
                            Q(student_owner__isnull=True) |
                            Q(student_owner__user_roles__in=subordinate_user_roles)
                        )
                students_to_update.update(student_owner=self.user)

            # For student accounts - Modified to handle zone head assignments properly
            student_account_filter = Q()
            if self.city:
                student_account_filter = Q(city__iexact=self.city)
            elif self.state:
                student_account_filter = Q(state__iexact=self.state)
            elif self.zone:
                student_account_filter = Q(zone__iexact=self.zone)
            
            if student_account_filter:
                student_accounts_to_update = StudentAccount.objects.filter(student_account_filter)
                if self.role.name != 'regional_head':
                    # For zone heads, only filter out accounts owned by city/state heads
                    if self.role.name == 'zonal_head':
                        student_accounts_to_update = student_accounts_to_update.filter(
                            Q(account_owner__isnull=True) |
                            Q(account_owner__user_roles__role__name__in=['regional_head'])
                        )
                    else:
                        student_accounts_to_update = student_accounts_to_update.filter(
                            Q(account_owner__isnull=True) |
                            Q(account_owner__user_roles__in=subordinate_user_roles)
                        )
                student_accounts_to_update.update(account_owner=self.user)

    def get_subordinates(self):
        """Get all users that report to this user based on role hierarchy and location"""
        subordinate_roles = Role.objects.filter(parent_role=self.role)
        subordinates = UserRole.objects.filter(role__in=subordinate_roles)

        # Filter by location hierarchy
        if self.city:
            subordinates = subordinates.filter(city=self.city)
        elif self.state:
            subordinates = subordinates.filter(state=self.state)
        elif self.zone:
            subordinates = subordinates.filter(zone=self.zone)

        return subordinates

    def can_manage_user(self, other_user_role):
        """Check if this user role can manage another user role"""
        # Check role hierarchy
        if self.role == other_user_role.role.parent_role:
            # Check location hierarchy
            if self.city:
                return self.city == other_user_role.city
            elif self.state:
                return self.state == other_user_role.state
            elif self.zone:
                return self.zone == other_user_role.zone
            return True
        return False 