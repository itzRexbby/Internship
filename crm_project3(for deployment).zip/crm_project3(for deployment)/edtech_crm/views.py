from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.db.models import Count, Sum, Q, Subquery, OuterRef
import pandas as pd
import io
from .models import UniversityLead, UniversityContact, UniversityAccount, UniversityOpportunity, ZONE_CHOICES, LEAD_STATUS_CHOICES, STUDENT_STATUS_CHOICES, Student, StudentAccount, Role, UserRole
from .forms import (
    UniversityLeadForm, 
    UniversityContactForm, 
    UniversityAccountForm, 
    UniversityOpportunityForm,
    ImportDataForm,
    StudentForm,
    StudentAccountForm,
    RoleForm,
    UserRoleForm
)
from django.template import TemplateDoesNotExist
from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.http import require_POST
import json
import subprocess
from django.urls import reverse
from django.utils import timezone
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Sum, Q
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.conf import settings
from datetime import datetime, timedelta
import uuid
from django.db.models.functions import ExtractYear, ExtractMonth

@login_required
def dashboard(request):
    # Admin can see all data
    if request.user.is_superuser:
        # Leads data
        leads = UniversityLead.objects.all()
        total_leads = leads.count()
        new_leads = leads.filter(lead_status='New').count()
        recent_leads = leads.order_by('-created_at')[:5]
        
        # Lead funnel data
        funnel_data = {
            'new': new_leads,
            'contacted': leads.filter(lead_status='Contacted').count(),
            'nurturing': leads.filter(lead_status='Nurturing').count(),
            'qualified': leads.filter(lead_status='Qualified').count(),
            'unqualified': leads.filter(lead_status='Unqualified').count(),
        }
        
        # Calculate total leads that have entered the pipeline (all statuses)
        total_in_pipeline = sum(funnel_data.values())
        
        # Calculate conversion rates for funnel based on the previous stage
        # This approach treats each conversion step independently
        funnel_rates = {
            'new_to_contacted': min(round((funnel_data['contacted'] / max(funnel_data['new'] + funnel_data['contacted'], 1) * 100), 1), 100),
            'contacted_to_nurturing': min(round((funnel_data['nurturing'] / max(funnel_data['contacted'] + funnel_data['nurturing'], 1) * 100), 1), 100),
            'nurturing_to_qualified': min(round((funnel_data['qualified'] / max(funnel_data['nurturing'] + funnel_data['qualified'], 1) * 100), 1), 100),
            'overall_conversion': min(round((funnel_data['qualified'] / max(total_in_pipeline, 1) * 100), 1), 100)
        }

        # Calculate monthly lead counts for trend line chart
        # Get the earliest lead created year and current year
        
        # Get all years with leads
        years_with_leads = leads.annotate(year=ExtractYear('created_at')).values('year').distinct().order_by('year')
        available_years = [year['year'] for year in years_with_leads]
        
        # If no leads exist yet, use current year as default
        if not available_years:
            available_years = [timezone.now().year]
        
        # Get monthly data for each year
        monthly_lead_data = {}
        
        for year in available_years:
            # Create a list for all months (1-12)
            year_data = [0] * 12
            
            # Query to get count of leads by month for this year
            monthly_counts = leads.filter(created_at__year=year)\
                .annotate(month=ExtractMonth('created_at'))\
                .values('month')\
                .annotate(count=Count('id'))\
                .order_by('month')
            
            # Fill in the data
            for month_data in monthly_counts:
                month_index = month_data['month'] - 1  # Convert 1-based to 0-based index
                year_data[month_index] = month_data['count']
            
            monthly_lead_data[year] = year_data
                
        # Contacts data
        contacts = UniversityContact.objects.all()
        total_contacts = contacts.count()
        active_contacts = contacts.filter(contact_owner__isnull=False).count()
        recent_contacts = contacts.order_by('-created_at')[:5]

        # Accounts data
        accounts = UniversityAccount.objects.all()
        total_accounts = accounts.count()
        active_accounts = accounts.filter(account_owner__isnull=False).count()
        recent_accounts = accounts.order_by('-created_at')[:5]

        # Opportunities data
        opportunities = UniversityOpportunity.objects.all()
        total_opportunities = opportunities.count()
        open_opportunities = opportunities.exclude(stage__in=['Closed Won', 'Closed Lost']).count()
        total_amount = opportunities.aggregate(total=Sum('amount'))['total'] or 0
        recent_opportunities = opportunities.order_by('-created_at')[:5]

        # Students data
        students = Student.objects.all()
        total_students = students.count()
        active_students = students.filter(status='customer').count()
        recent_students = students.order_by('-created_at')[:5]

        # Student Accounts data
        student_accounts = StudentAccount.objects.all()
        total_student_accounts = student_accounts.count()
        active_student_accounts = student_accounts.filter(status='active').count()
        recent_student_accounts = student_accounts.order_by('-created_at')[:5]
        
        # User performance data - for admin view (all users)
        users = User.objects.filter(is_active=True).exclude(is_superuser=True)
        user_stats = []
        
        for user in users:
            user_data = {
                'user': user,
                'leads_count': leads.filter(lead_owner=user).count(),
                'contacts_count': contacts.filter(contact_owner=user).count(),
                'accounts_count': accounts.filter(account_owner=user).count(),
                'opportunities_count': opportunities.filter(opportunity_owner=user).count(),
                'opportunities_won': opportunities.filter(opportunity_owner=user, stage='Closed Won').count(),
                'qualified_leads': leads.filter(lead_owner=user, lead_status='Qualified').count(),
                'total_opportunity_amount': opportunities.filter(opportunity_owner=user).aggregate(total=Sum('amount'))['total'] or 0,
                'won_opportunity_amount': opportunities.filter(opportunity_owner=user, stage='Closed Won').aggregate(total=Sum('amount'))['total'] or 0,
            }
            
            # Calculate conversion rates
            if user_data['leads_count'] > 0:
                user_data['lead_conversion_rate'] = round((user_data['qualified_leads'] / user_data['leads_count']) * 100, 1)
            else:
                user_data['lead_conversion_rate'] = 0
                
            if user_data['opportunities_count'] > 0:
                user_data['win_rate'] = round((user_data['opportunities_won'] / user_data['opportunities_count']) * 100, 1)
            else:
                user_data['win_rate'] = 0
                
            user_stats.append(user_data)
        
        # Sort by total opportunity amount (descending)
        user_stats.sort(key=lambda x: x['total_opportunity_amount'], reverse=True)

    else:
        # Get all user roles
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        
        # Initialize base queryset with directly assigned items
        leads_filter = Q(lead_owner=request.user)
        contacts_filter = Q(contact_owner=request.user)
        accounts_filter = Q(account_owner=request.user)
        opportunities_filter = Q(opportunity_owner=request.user)
        students_filter = Q(student_owner=request.user)
        student_accounts_filter = Q(account_owner=request.user)
        
        # Initialize an empty list to store all visible subordinate users
        visible_users = []
        
        # For tracking if user is a regional head (can see everything)
        is_regional_head = False
        
        # Check if user has any roles
        if user_roles.exists():
            # Get all subordinate users from each role
            for user_role in user_roles:
                # Check for regional head (can see everything)
                if user_role.role.name == 'regional_head':
                    is_regional_head = True
                    leads_filter = Q()  # Empty Q object means no filter (all records)
                    contacts_filter = Q()
                    accounts_filter = Q()
                    opportunities_filter = Q()
                    students_filter = Q()
                    student_accounts_filter = Q()
                    
                    # Regional head can see all users
                    visible_users = list(User.objects.filter(is_active=True).exclude(is_superuser=True))
                    break  # No need to check other roles
                
                # For other roles, collect subordinate users based on hierarchy
                subordinate_user_roles = user_role.get_subordinates()
                for sub_role in subordinate_user_roles:
                    if sub_role.user not in visible_users:
                        visible_users.append(sub_role.user)
                
                # Always include self
                if request.user not in visible_users:
                    visible_users.append(request.user)
                
                # Zone heads can see everything in their zone
                if user_role.zone and not user_role.state and not user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone)
                    contacts_filter |= Q(zone__iexact=user_role.zone)
                    accounts_filter |= Q(zone__iexact=user_role.zone)
                    opportunities_filter |= Q(zone__iexact=user_role.zone)
                    students_filter |= Q(zone__iexact=user_role.zone)
                    student_accounts_filter |= Q(zone__iexact=user_role.zone)
                
                # State heads can see everything in their state
                elif user_role.zone and user_role.state and not user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state)
                    contacts_filter |= Q(zone__iexact=user_role.zone, mailing_state__iexact=user_role.state)
                    accounts_filter |= Q(zone__iexact=user_role.zone, billing_state__iexact=user_role.state)
                    opportunities_filter |= Q(zone__iexact=user_role.zone, lead__state__iexact=user_role.state)
                    students_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state)
                    student_accounts_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state)
                
                # City heads can see everything in their city
                elif user_role.zone and user_role.state and user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state, city__iexact=user_role.city)
                    contacts_filter |= Q(zone__iexact=user_role.zone, mailing_state__iexact=user_role.state, mailing_city__iexact=user_role.city)
                    accounts_filter |= Q(zone__iexact=user_role.zone, billing_state__iexact=user_role.state, billing_city__iexact=user_role.city)
                    opportunities_filter |= Q(zone__iexact=user_role.zone, lead__state__iexact=user_role.state, lead__city__iexact=user_role.city)
                    students_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state, city__iexact=user_role.city)
                    student_accounts_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state, city__iexact=user_role.city)
        
        # Apply filters to get visible records
        leads = UniversityLead.objects.filter(leads_filter).distinct()
        contacts = UniversityContact.objects.filter(contacts_filter).distinct()
        accounts = UniversityAccount.objects.filter(accounts_filter).distinct()
        opportunities = UniversityOpportunity.objects.filter(opportunities_filter).distinct()
        students = Student.objects.filter(students_filter).distinct()
        student_accounts = StudentAccount.objects.filter(student_accounts_filter).distinct()
        
        # Calculate statistics
        total_leads = leads.count()
        new_leads = leads.filter(lead_status='New').count()
        recent_leads = leads.order_by('-created_at')[:5]
        
        total_contacts = contacts.count()
        active_contacts = contacts.filter(contact_owner__isnull=False).count()
        recent_contacts = contacts.order_by('-created_at')[:5]
        
        total_accounts = accounts.count()
        active_accounts = accounts.filter(account_owner__isnull=False).count()
        recent_accounts = accounts.order_by('-created_at')[:5]
        
        total_opportunities = opportunities.count()
        open_opportunities = opportunities.exclude(stage__in=['Closed Won', 'Closed Lost']).count()
        total_amount = opportunities.aggregate(total=Sum('amount'))['total'] or 0
        recent_opportunities = opportunities.order_by('-created_at')[:5]
        
        total_students = students.count()
        active_students = students.filter(status='customer').count()
        recent_students = students.order_by('-created_at')[:5]
        
        total_student_accounts = student_accounts.count()
        active_student_accounts = student_accounts.filter(status='active').count()
        recent_student_accounts = student_accounts.order_by('-created_at')[:5]
        
        # User performance data for non-admin users - only visible subordinates based on hierarchy
        user_stats = []
        
        if visible_users:
            for user in visible_users:
                user_data = {
                    'user': user,
                    'leads_count': leads.filter(lead_owner=user).count(),
                    'contacts_count': contacts.filter(contact_owner=user).count(),
                    'accounts_count': accounts.filter(account_owner=user).count(),
                    'opportunities_count': opportunities.filter(opportunity_owner=user).count(),
                    'opportunities_won': opportunities.filter(opportunity_owner=user, stage='Closed Won').count(),
                    'qualified_leads': leads.filter(lead_owner=user, lead_status='Qualified').count(),
                    'total_opportunity_amount': opportunities.filter(opportunity_owner=user).aggregate(total=Sum('amount'))['total'] or 0,
                    'won_opportunity_amount': opportunities.filter(opportunity_owner=user, stage='Closed Won').aggregate(total=Sum('amount'))['total'] or 0,
                }
                
                # Calculate conversion rates
                if user_data['leads_count'] > 0:
                    user_data['lead_conversion_rate'] = round((user_data['qualified_leads'] / user_data['leads_count']) * 100, 1)
                else:
                    user_data['lead_conversion_rate'] = 0
                    
                if user_data['opportunities_count'] > 0:
                    user_data['win_rate'] = round((user_data['opportunities_won'] / user_data['opportunities_count']) * 100, 1)
                else:
                    user_data['win_rate'] = 0
                    
                user_stats.append(user_data)
            
            # Sort by total opportunity amount (descending)
            user_stats.sort(key=lambda x: x['total_opportunity_amount'], reverse=True)

        # Lead funnel data for non-admin users
        funnel_data = {
            'new': new_leads,
            'contacted': leads.filter(lead_status='Contacted').count(),
            'nurturing': leads.filter(lead_status='Nurturing').count(), 
            'qualified': leads.filter(lead_status='Qualified').count(),
            'unqualified': leads.filter(lead_status='Unqualified').count(),
        }
        
        # Calculate total leads that have entered the pipeline (all statuses)
        total_in_pipeline = sum(funnel_data.values())
        
        # Calculate conversion rates for funnel based on the previous stage
        # This approach treats each conversion step independently
        funnel_rates = {
            'new_to_contacted': min(round((funnel_data['contacted'] / max(funnel_data['new'] + funnel_data['contacted'], 1) * 100), 1), 100),
            'contacted_to_nurturing': min(round((funnel_data['nurturing'] / max(funnel_data['contacted'] + funnel_data['nurturing'], 1) * 100), 1), 100),
            'nurturing_to_qualified': min(round((funnel_data['qualified'] / max(funnel_data['nurturing'] + funnel_data['qualified'], 1) * 100), 1), 100),
            'overall_conversion': min(round((funnel_data['qualified'] / max(total_in_pipeline, 1) * 100), 1), 100)
        }
        
        # Calculate monthly lead counts for trend line chart
        # Get all years with leads
        years_with_leads = leads.annotate(year=ExtractYear('created_at')).values('year').distinct().order_by('year')
        available_years = [year['year'] for year in years_with_leads]
        
        # If no leads exist yet, use current year as default
        if not available_years:
            available_years = [timezone.now().year]
        
        # Get monthly data for each year
        monthly_lead_data = {}
        
        for year in available_years:
            # Create a list for all months (1-12)
            year_data = [0] * 12
            
            # Query to get count of leads by month for this year
            monthly_counts = leads.filter(created_at__year=year)\
                .annotate(month=ExtractMonth('created_at'))\
                .values('month')\
                .annotate(count=Count('id'))\
                .order_by('month')
            
            # Fill in the data
            for month_data in monthly_counts:
                month_index = month_data['month'] - 1  # Convert 1-based to 0-based index
                year_data[month_index] = month_data['count']
            
            monthly_lead_data[year] = year_data
        
    context = {
        'total_leads': total_leads,
        'new_leads': new_leads,
        'recent_leads': recent_leads,
        
        # Add funnel data to context
        'funnel_data': funnel_data,
        'funnel_rates': funnel_rates,
        
        # Add monthly lead data for trend chart
        'monthly_lead_data': json.dumps(monthly_lead_data),
        'available_years': available_years,
        
        'total_contacts': total_contacts,
        'active_contacts': active_contacts,
        'recent_contacts': recent_contacts,
        
        'total_accounts': total_accounts,
        'active_accounts': active_accounts,
        'recent_accounts': recent_accounts,
        
        'total_opportunities': total_opportunities,
        'open_opportunities': open_opportunities,
        'total_amount': total_amount,
        'recent_opportunities': recent_opportunities,
        
        'total_students': total_students,
        'active_students': active_students,
        'recent_students': recent_students,
        
        'total_student_accounts': total_student_accounts,
        'active_student_accounts': active_student_accounts,
        'recent_student_accounts': recent_student_accounts,
        
        # User performance data based on user's role
        'user_stats': user_stats,
    }
    
    return render(request, 'dashboard.html', context)

# University Lead Views
@login_required
def lead_list(request):
    # Admin can see all leads
    if request.user.is_superuser:
        leads = UniversityLead.objects.all()
    else:
        # Get all user roles
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        
        # If user has no roles, show only directly assigned leads
        if not user_roles.exists():
            leads = UniversityLead.objects.filter(lead_owner=request.user)
        else:
            # Initialize an empty Q object for the query
            leads_filter = Q()
            
            # Process each user role to determine which leads should be visible
            for user_role in user_roles:
                # Zone heads can see all leads in their zone
                if user_role.zone and not user_role.state and not user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone)
                
                # State heads can see all leads in their state
                elif user_role.zone and user_role.state and not user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state)
                
                # City heads can see only leads in their city
                elif user_role.zone and user_role.state and user_role.city:
                    leads_filter |= Q(zone__iexact=user_role.zone, state__iexact=user_role.state, city__iexact=user_role.city)
                
                # Regional heads can see all leads
                elif user_role.role.name == 'regional_head':
                    leads_filter = Q()  # Clear filter to see all leads
                    break  # No need to check other roles
            
            # Query the leads based on the constructed filter or directly assigned leads
            leads = UniversityLead.objects.filter(
                Q(lead_owner=request.user) | leads_filter
            ).distinct()
    
    # Get search and filter parameters
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')
    zone_filter = request.GET.get('zone', '')
    
    # Apply search filter
    if search_query:
        leads = leads.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(university_name__icontains=search_query) |
            Q(title__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    # Apply status filter
    if status_filter:
        leads = leads.filter(lead_status=status_filter)
    
    # Apply zone filter
    if zone_filter:
        leads = leads.filter(zone=zone_filter)
    
    # Order by created_at
    leads = leads.order_by('-updated_at')
    
    # Calculate lead statistics based on filtered leads
    lead_stats = {
        'new_leads': leads.filter(lead_status='New').count(),
        'contacted_leads': leads.filter(lead_status='Contacted').count(),
        'qualified_leads': leads.filter(lead_status='Qualified').count(),
        'total_leads': leads.count(),
    }
    
    context = {
        'leads': leads,
        'lead_stats': lead_stats,
        'search_query': search_query,
        'status_filter': status_filter,
        'zone_filter': zone_filter,
        'lead_status_choices': LEAD_STATUS_CHOICES,
        'zone_choices': ZONE_CHOICES,
    }
    
    return render(request, 'edtech_crm/lead_list.html', context)

@login_required
def lead_detail(request, pk):
    lead = get_object_or_404(UniversityLead, pk=pk)
    
    # Check if user has access to this lead
    if not request.user.is_superuser and not user_has_lead_access(request.user, lead):
        return HttpResponseForbidden("You don't have permission to view this lead.")
    
    # Get opportunities related to this lead
    if request.user.is_superuser:
        related_opportunities = lead.opportunities.all()
        related_contacts = UniversityContact.objects.filter(university_name=lead.university_name)
        related_accounts = UniversityAccount.objects.filter(account_name=lead.university_name)
    else:
        # Filter related items based on user's roles
        related_opportunities = lead.opportunities.filter(
            Q(opportunity_owner=request.user) | 
            Q(zone=lead.zone)  # Simplified for now, we can add more specific filtering if needed
        ).distinct()
        
        related_contacts = UniversityContact.objects.filter(
            Q(contact_owner=request.user) | 
            Q(university_name=lead.university_name, zone=lead.zone)
        ).distinct()
        
        related_accounts = UniversityAccount.objects.filter(
            Q(account_owner=request.user) | 
            Q(account_name=lead.university_name, zone=lead.zone)
        ).distinct()

    return render(request, 'edtech_crm/lead_detail.html', {
        'lead': lead,
        'related_opportunities': related_opportunities,
        'related_contacts': related_contacts,
        'related_accounts': related_accounts
    })

@login_required
def lead_create(request):
    if request.method == 'POST':
        form = UniversityLeadForm(request.POST)
        if form.is_valid():
            lead = form.save()
            messages.success(request, 'Lead created successfully!')
            return redirect('lead_detail', pk=lead.pk)
    else:
        form = UniversityLeadForm()
    
    return render(request, 'leads/form.html', {'form': form, 'action': 'Create'})

@login_required
def lead_update(request, pk):
    lead = get_object_or_404(UniversityLead, pk=pk)
    
    # Check if user has access to this lead
    if not request.user.is_superuser and not user_has_lead_access(request.user, lead):
        return HttpResponseForbidden("You don't have permission to update this lead.")
    
    if request.method == 'POST':
        form = UniversityLeadForm(request.POST, instance=lead, user=request.user)
        if form.is_valid():
            updated_lead = form.save(commit=False)
            # Only preserve lead_owner for non-admin users
            if not request.user.is_superuser:
                updated_lead.lead_owner = lead.lead_owner
            updated_lead.save()
            messages.success(request, 'Lead updated successfully!')
            return redirect('lead_detail', pk=lead.pk)
    else:
        form = UniversityLeadForm(instance=lead, user=request.user)
    
    return render(request, 'leads/form.html', {'form': form, 'lead': lead, 'action': 'Update'})

@login_required
def lead_delete(request, pk):
    lead = get_object_or_404(UniversityLead, pk=pk)
    
    # Check if user has access to this lead
    if not request.user.is_superuser and not user_has_lead_access(request.user, lead):
        return HttpResponseForbidden("You don't have permission to delete this lead.")
    
    if request.method == 'POST':
        lead.delete()
        messages.success(request, 'Lead deleted successfully!')
        return redirect('lead_list')
    
    return render(request, 'edtech_crm/lead_delete.html', {'lead': lead})

# University Contact Views
def user_has_contact_access(user, contact):
    """Helper function to check if a user has access to a contact based on role and location"""
    # Admin or owner always has access
    if user.is_superuser or user.is_staff or user == contact.contact_owner:
        return True
    
    # Check if user has roles that give access to this contact
    user_roles = UserRole.objects.filter(user=user, is_active=True)
    
    for user_role in user_roles:
        # Zone heads can see all contacts in their zone
        if user_role.zone and contact.zone and user_role.zone.lower() == contact.zone.lower() and not user_role.state and not user_role.city:
            return True
            
        # State heads can see all contacts in their state (assuming same zone)
        if (user_role.zone and contact.zone and user_role.zone.lower() == contact.zone.lower() and
            user_role.state and contact.mailing_state and user_role.state.lower() == contact.mailing_state.lower() and 
            not user_role.city):
            return True
            
        # City heads can see only their city contacts
        if (user_role.zone and contact.zone and user_role.zone.lower() == contact.zone.lower() and
            user_role.state and contact.mailing_state and user_role.state.lower() == contact.mailing_state.lower() and
            user_role.city and contact.mailing_city and user_role.city.lower() == contact.mailing_city.lower()):
            return True
            
        # Regional Head has access to all contacts
        if user_role.role.name == 'regional_head':
            return True
    
    return False

@login_required
def contact_list(request):
    # Admin can see all contacts
    if request.user.is_superuser:
        contacts = UniversityContact.objects.all()
    else:
        # Get all user roles
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        
        # If user has no roles, show only directly assigned contacts
        if not user_roles.exists():
            contacts = UniversityContact.objects.filter(contact_owner=request.user)
        else:
            # Initialize an empty Q object for the query
            contacts_filter = Q()
            
            # Process each user role to determine which contacts should be visible
            for user_role in user_roles:
                # Zone heads can see all contacts in their zone
                if user_role.zone and not user_role.state and not user_role.city:
                    contacts_filter |= Q(zone__iexact=user_role.zone)
                
                # State heads can see all contacts in their state
                elif user_role.zone and user_role.state and not user_role.city:
                    contacts_filter |= Q(zone__iexact=user_role.zone, mailing_state__iexact=user_role.state)
                
                # City heads can see only contacts in their city
                elif user_role.zone and user_role.state and user_role.city:
                    contacts_filter |= Q(zone__iexact=user_role.zone, mailing_state__iexact=user_role.state, mailing_city__iexact=user_role.city)
                
                # Regional heads can see all contacts
                elif user_role.role.name == 'regional_head':
                    contacts_filter = Q()  # Clear filter to see all contacts
                    break  # No need to check other roles
            
            # Query the contacts based on the constructed filter or directly assigned contacts
            contacts = UniversityContact.objects.filter(
                Q(contact_owner=request.user) | contacts_filter
            ).distinct()
    
    # Get search and filter parameters
    search_query = request.GET.get('search', '')
    zone_filter = request.GET.get('zone', '')
    
    # Apply search filter
    if search_query:
        contacts = contacts.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(university_name__icontains=search_query) |
            Q(title__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    # Apply zone filter
    if zone_filter:
        contacts = contacts.filter(zone=zone_filter)
    
    # Order by created_at
    contacts = contacts.order_by('-created_at')
    
    context = {
        'contacts': contacts,
        'search_query': search_query,
        'zone_filter': zone_filter,
        'zone_choices': ZONE_CHOICES,
    }
    
    return render(request, 'edtech_crm/contact_list.html', context)

@login_required
def contact_detail(request, pk):
    contact = get_object_or_404(UniversityContact, pk=pk)
    
    # Check if user has access to this contact
    if not request.user.is_superuser and not user_has_contact_access(request.user, contact):
        return HttpResponseForbidden("You don't have permission to view this contact.")
    
    return render(request, 'edtech_crm/contact_detail.html', {'contact': contact})

@login_required
def contact_create(request):
    if request.method == 'POST':
        form = UniversityContactForm(request.POST, user=request.user)
        if form.is_valid():
            contact = form.save(commit=False)
            contact.contact_owner = request.user
            contact.user = request.user
            contact.save()
            messages.success(request, 'Contact created successfully!')
            return redirect('contact_detail', pk=contact.pk)
    else:
        form = UniversityContactForm(user=request.user)
    
    try:
        return render(request, 'edtech_crm/contact_form.html', {'form': form, 'action': 'Create'})
    except TemplateDoesNotExist:
        return redirect('contact_list')

@login_required
def contact_update(request, pk):
    contact = get_object_or_404(UniversityContact, pk=pk)
    
    # Check if user has access to this contact
    if not request.user.is_superuser and not user_has_contact_access(request.user, contact):
        return HttpResponseForbidden("You don't have permission to update this contact.")
    
    if request.method == 'POST':
        form = UniversityContactForm(request.POST, instance=contact, user=request.user)
        if form.is_valid():
            updated_contact = form.save(commit=False)
            if not request.user.is_superuser:
                updated_contact.contact_owner = contact.contact_owner
            updated_contact.save()
            messages.success(request, 'Contact updated successfully!')
            return redirect('contact_detail', pk=contact.pk)
    else:
        form = UniversityContactForm(instance=contact, user=request.user)
    
    try:
        return render(request, 'edtech_crm/contact_form.html', {'form': form, 'contact': contact, 'action': 'Update'})
    except TemplateDoesNotExist:
        return redirect('contact_list')

@login_required
def contact_delete(request, pk):
    contact = get_object_or_404(UniversityContact, pk=pk)
    
    # Check if user has access to this contact
    if not request.user.is_superuser and not user_has_contact_access(request.user, contact):
        return HttpResponseForbidden("You don't have permission to delete this contact.")
    
    if request.method == 'POST':
        contact.delete()
        messages.success(request, 'Contact deleted successfully!')
        return redirect('contact_list')
    
    return render(request, 'edtech_crm/contact_confirm_delete.html', {'contact': contact})

# University Account Views
@login_required
def account_list(request):
    if request.user.is_superuser:
        accounts = UniversityAccount.objects.all().order_by('-created_at')
    else:
        accounts = UniversityAccount.objects.filter(account_owner=request.user).order_by('-created_at')
    return render(request, 'edtech_crm/account_list.html', {'accounts': accounts})

@login_required
def account_detail(request, pk):
    if request.user.is_superuser:
        account = get_object_or_404(UniversityAccount, pk=pk)
    else:
        account = get_object_or_404(UniversityAccount, pk=pk, account_owner=request.user)
    return render(request, 'edtech_crm/account_detail.html', {'account': account})

@login_required
def account_create(request):
    if request.method == 'POST':
        form = UniversityAccountForm(request.POST, user=request.user)
        if form.is_valid():
            account = form.save(commit=False)
            account.account_owner = request.user
            account.user = request.user
            account.save()
            messages.success(request, 'Account created successfully!')
            return redirect('account_detail', pk=account.pk)
    else:
        form = UniversityAccountForm(user=request.user)
    
    try:
        return render(request, 'edtech_crm/account_form.html', {'form': form, 'action': 'Create'})
    except TemplateDoesNotExist:
        return redirect('account_list')

@login_required
def account_update(request, pk):
    if request.user.is_superuser or request.user.is_staff:
        account = get_object_or_404(UniversityAccount, pk=pk)
    else:
        account = get_object_or_404(UniversityAccount, pk=pk, user=request.user)
    
    if request.method == 'POST':
        form = UniversityAccountForm(request.POST, instance=account, user=request.user)
        if form.is_valid():
            updated_account = form.save(commit=False)
            if not request.user.is_superuser:
                updated_account.account_owner = account.account_owner
            updated_account.save()
            messages.success(request, 'Account updated successfully!')
            return redirect('account_detail', pk=account.pk)
    else:
        form = UniversityAccountForm(instance=account, user=request.user)
    
    try:
        return render(request, 'edtech_crm/account_form.html', {'form': form, 'account': account, 'action': 'Update'})
    except TemplateDoesNotExist:
        return redirect('account_list')

@login_required
def account_delete(request, pk):
    # Allow admins to delete any account, regular users only their assigned accounts
    if request.user.is_superuser or request.user.is_staff:
        account = get_object_or_404(UniversityAccount, pk=pk)
    else:
        account = get_object_or_404(UniversityAccount, pk=pk, user=request.user)
    
    if request.method == 'POST':
        account.delete()
        messages.success(request, 'Account deleted successfully!')
        return redirect('account_list')
    
    return render(request, 'edtech_crm/account_confirm_delete.html', {'account': account})

# University Opportunity Views
@login_required
def opportunity_list(request):
    if request.user.is_superuser:
        opportunities = UniversityOpportunity.objects.all().order_by('-created_at')
    else:
        opportunities = UniversityOpportunity.objects.filter(opportunity_owner=request.user).order_by('-created_at')
    
    # Calculate total amount using aggregation
    total = opportunities.aggregate(total=Sum('amount'))['total'] or 0

    # Calculate other stats
    won_opportunities = opportunities.filter(stage='Closed Won').count()
    open_opportunities = opportunities.exclude(stage__in=['Closed Won', 'Closed Lost']).count()
    
    context = {
        'opportunities': opportunities,
        'total_amount': total,
        'won_opportunities': won_opportunities,
        'open_opportunities': open_opportunities
    }
    
    return render(request, 'edtech_crm/opportunity_list.html', context)

@login_required
def opportunity_detail(request, pk):
    if request.user.is_superuser:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk)
    else:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk, opportunity_owner=request.user)
    return render(request, 'edtech_crm/opportunity_detail.html', {'opportunity': opportunity})

@login_required
def opportunity_create(request):
    if request.method == 'POST':
        form = UniversityOpportunityForm(request.POST, user=request.user)
        if form.is_valid():
            opportunity = form.save(commit=False)
            opportunity.opportunity_owner = request.user
            opportunity.user = request.user
            opportunity.save()
            messages.success(request, 'Opportunity created successfully!')
            return redirect('opportunity_detail', pk=opportunity.pk)
    else:
        form = UniversityOpportunityForm(user=request.user)
    
    try:
        return render(request, 'edtech_crm/opportunity_form.html', {'form': form, 'action': 'Create'})
    except TemplateDoesNotExist:
        return redirect('opportunity_list')

@login_required
def opportunity_update(request, pk):
    if request.user.is_superuser or request.user.is_staff:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk)
    else:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk, opportunity_owner=request.user)
    
    if request.method == 'POST':
        form = UniversityOpportunityForm(request.POST, instance=opportunity, user=request.user)
        if form.is_valid():
            updated_opportunity = form.save(commit=False)
            if not request.user.is_superuser:
                updated_opportunity.opportunity_owner = opportunity.opportunity_owner
            updated_opportunity.save()
            messages.success(request, 'Opportunity updated successfully!')
            return redirect('opportunity_detail', pk=opportunity.pk)
    else:
        form = UniversityOpportunityForm(instance=opportunity, user=request.user)
    
    try:
        return render(request, 'edtech_crm/opportunity_form.html', {'form': form, 'opportunity': opportunity, 'action': 'Update'})
    except TemplateDoesNotExist:
        return redirect('opportunity_list')

@login_required
def opportunity_delete(request, pk):
    # Allow admins to delete any opportunity, regular users only their assigned opportunities
    if request.user.is_superuser or request.user.is_staff:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk)
    else:
        opportunity = get_object_or_404(UniversityOpportunity, pk=pk, opportunity_owner=request.user)
    
    if request.method == 'POST':
        opportunity.delete()
        messages.success(request, 'Opportunity deleted successfully!')
        return redirect('opportunity_list')
    
    return render(request, 'edtech_crm/opportunity_confirm_delete.html', {'opportunity': opportunity})

# Import/Export Views
@login_required
def import_leads(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to import leads.')
        return redirect('lead_list')
        
    if request.method == 'POST':
        form = ImportDataForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                # Read Excel or CSV file
                file = request.FILES['file']
                if file.name.endswith('.xlsx'):
                    df = pd.read_excel(file)
                elif file.name.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    messages.error(request, 'Unsupported file format. Please upload an Excel (.xlsx) or CSV file.')
                    return redirect('import_leads')
                
                # Process data
                imported_count = 0
                for _, row in df.iterrows():
                    # Handle NaN values for all fields by converting to appropriate types
                    # Initialize all fields that might be imported
                    fields = {}
                    
                    # String fields - convert NaN to empty string
                    string_fields = [
                        'first_name', 'last_name', 'university_name', 'title', 'website',
                        'description', 'lead_status', 'phone', 'email', 'street',
                        'city', 'zipcode', 'state', 'country', 'industry',
                        'lead_source', 'zone'
                    ]
                    
                    for field in string_fields:
                        if field in row and pd.notna(row.get(field)):
                            fields[field] = str(row.get(field)).strip()
                        else:
                            fields[field] = ''
                    
                    # Numeric fields - convert NaN to None
                    if 'no_of_students' in row and pd.notna(row.get('no_of_students')):
                        try:
                            fields['no_of_students'] = int(row.get('no_of_students'))
                        except (ValueError, TypeError):
                            fields['no_of_students'] = None
                    else:
                        fields['no_of_students'] = None
                    
                    if 'annual_revenue' in row and pd.notna(row.get('annual_revenue')):
                        try:
                            fields['annual_revenue'] = row.get('annual_revenue')
                        except (ValueError, TypeError):
                            fields['annual_revenue'] = None
                    else:
                        fields['annual_revenue'] = None
                    
                    # Set default values for required fields
                    if not fields['lead_status']:
                        fields['lead_status'] = 'New'
                    
                    if not fields['lead_source']:
                        fields['lead_source'] = 'None'
                    
                    if not fields['zone']:
                        fields['zone'] = 'None'
                    
                    # Create the lead with all processed fields
                    lead = UniversityLead(
                        first_name=fields['first_name'],
                        last_name=fields['last_name'],
                        university_name=fields['university_name'],
                        title=fields['title'],
                        website=fields['website'],
                        description=fields['description'],
                        lead_status=fields['lead_status'],
                        phone=fields['phone'],
                        email=fields['email'],
                        street=fields['street'],
                        city=fields['city'],
                        zipcode=fields['zipcode'],
                        state=fields['state'],
                        country=fields['country'],
                        no_of_students=fields['no_of_students'],
                        annual_revenue=fields['annual_revenue'],
                        lead_source=fields['lead_source'],
                        industry=fields['industry'],
                        zone=fields['zone'],
                    )
                    
                    # Save the lead - this will trigger the automatic owner assignment in the model's save method
                    # based on the zone/state/city hierarchy
                    lead.save()
                    imported_count += 1
                
                messages.success(request, f'Successfully imported {imported_count} leads. Leads have been automatically assigned based on zone, state, and city hierarchy.')
                return redirect('lead_list')
            
            except Exception as e:
                messages.error(request, f'Error importing data: {str(e)}')
                return redirect('import_leads')
    else:
        form = ImportDataForm()
    
    # Add information about expected columns to help users
    expected_columns = [
        'first_name', 'last_name', 'university_name', 'title', 'website', 
        'description', 'lead_status', 'phone', 'email', 'street', 
        'city', 'zipcode', 'state', 'country', 'zone', 
        'no_of_students', 'annual_revenue', 'lead_source', 'industry'
    ]
    
    return render(request, 'edtech_crm/import_form.html', {
        'form': form, 
        'model_type': 'Leads',
        'expected_columns': expected_columns
    })

@login_required
def export_leads(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to export leads.')
        return redirect('lead_list')
        
    # Get all leads
    leads = UniversityLead.objects.all()
    
    # Create DataFrame
    data = []
    for lead in leads:
        data.append({
            'id': lead.id,
            'first_name': lead.first_name,
            'last_name': lead.last_name,
            'university_name': lead.university_name,
            'title': lead.title,
            'website': lead.website,
            'description': lead.description,
            'lead_status': lead.lead_status,
            'lead_owner': lead.lead_owner.username if lead.lead_owner else '',
            'phone': lead.phone,
            'email': lead.email,
            'street': lead.street,
            'city': lead.city,
            'zipcode': lead.zipcode,
            'state': lead.state,
            'country': lead.country,
            'no_of_students': lead.no_of_students,
            'annual_revenue': lead.annual_revenue,
            'lead_source': lead.lead_source,
            'industry': lead.industry,
            'created_at': lead.created_at,
            'updated_at': lead.updated_at,
        })
    
    df = pd.DataFrame(data)
    
    # Convert datetime fields to timezone-unaware
    df['created_at'] = df['created_at'].dt.tz_localize(None)
    df['updated_at'] = df['updated_at'].dt.tz_localize(None)
    
    # Create Excel file
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Leads')
    
    # Prepare response
    output.seek(0)
    response = HttpResponse(output.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=university_leads.xlsx'
    
    return response

# Admin views for assigning items to users
@staff_member_required
@require_POST
def assign_lead(request):
    """Assign a lead to a user"""
    try:
        data = json.loads(request.body)
        lead_id = data.get('lead_id')
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        lead = get_object_or_404(UniversityLead, pk=lead_id)
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        lead.user = request.user
        lead.save()
        
        return JsonResponse({'status': 'success', 'message': f'Lead assigned to {request.user.username}'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@staff_member_required
@require_POST
def assign_contact(request):
    """Assign a contact to a user"""
    try:
        data = json.loads(request.body)
        contact_id = data.get('contact_id')
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        contact = get_object_or_404(UniversityContact, pk=contact_id)
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        contact.user = request.user
        contact.save()
        
        return JsonResponse({'status': 'success', 'message': f'Contact assigned to {request.user.username}'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@staff_member_required
@require_POST
def assign_account(request):
    """Assign an account to a user"""
    try:
        data = json.loads(request.body)
        account_id = data.get('account_id')
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        account = get_object_or_404(UniversityAccount, pk=account_id)
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        account.user = request.user
        account.save()
        
        return JsonResponse({'status': 'success', 'message': f'Account assigned to {request.user.username}'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@staff_member_required
@require_POST
def assign_opportunity(request):
    """Assign an opportunity to a user"""
    try:
        data = json.loads(request.body)
        opportunity_id = data.get('opportunity_id')
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        opportunity = get_object_or_404(UniversityOpportunity, pk=opportunity_id)
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        opportunity.user = request.user
        opportunity.save()
        
        return JsonResponse({'status': 'success', 'message': f'Opportunity assigned to {request.user.username}'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@staff_member_required
@require_POST
def bulk_assign_leads(request):
    """Bulk assign leads to a user"""
    try:
        data = json.loads(request.body)
        lead_ids = data.get('lead_ids', [])
        # Commenting out user_id retrieval and usage
        # user_id = data.get('user_id')
        # user = get_object_or_404(User, pk=user_id)
        
        for lead_id in lead_ids:
            lead = get_object_or_404(UniversityLead, pk=lead_id)
            # Commenting out user_id retrieval and usage
            # user_id = data.get('user_id')
            # user = get_object_or_404(User, pk=user_id)
            lead.user = request.user
            lead.save()
        
        return JsonResponse({
            'status': 'success', 
            'message': f'{len(lead_ids)} leads assigned to {request.user.username}'
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@login_required
def assignment_panel(request):
    # Check if user is superuser, if not redirect to dashboard
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to access the assignment panel.')
        return redirect('dashboard')
    
    # Get search and filter parameters
    search_query = request.GET.get('search', '')
    zone_filter = request.GET.get('zone', '')
    state_filter = request.GET.get('state', '')
    city_filter = request.GET.get('city', '')
    status_filter = request.GET.get('status', '')
    
    # Get base querysets
    users = User.objects.filter(is_active=True).order_by('username')
    leads = UniversityLead.objects.all()
    contacts = UniversityContact.objects.all()
    accounts = UniversityAccount.objects.all()
    opportunities = UniversityOpportunity.objects.all()
    students = Student.objects.all()
    student_accounts = StudentAccount.objects.all()
    
    # Apply search filter if provided
    if search_query:
        leads = leads.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(university_name__icontains=search_query) |
            Q(email__icontains=search_query)
        )
        contacts = contacts.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(university_name__icontains=search_query) |
            Q(email__icontains=search_query)
        )
        accounts = accounts.filter(
            Q(account_name__icontains=search_query) |
            Q(website__icontains=search_query)
        )
        opportunities = opportunities.filter(
            Q(opportunity_name__icontains=search_query) |
            Q(university_name__icontains=search_query)
        )
        students = students.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(email__icontains=search_query)
        )
        student_accounts = student_accounts.filter(
            Q(account_name__icontains=search_query) |
            Q(student__email__icontains=search_query)
        )
    
    # Apply hierarchical location filters
    if zone_filter:
        leads = leads.filter(zone=zone_filter)
        contacts = contacts.filter(zone=zone_filter)
        accounts = accounts.filter(zone=zone_filter)
        opportunities = opportunities.filter(zone=zone_filter)
        students = students.filter(zone=zone_filter)
        student_accounts = student_accounts.filter(zone=zone_filter)
        
        if state_filter:
            leads = leads.filter(state=state_filter)
            contacts = contacts.filter(mailing_state=state_filter)
            accounts = accounts.filter(billing_state=state_filter)
            students = students.filter(state=state_filter)
            student_accounts = student_accounts.filter(state=state_filter)
            
            if city_filter:
                leads = leads.filter(city=city_filter)
                contacts = contacts.filter(mailing_city=city_filter)
                accounts = accounts.filter(billing_city=city_filter)
                students = students.filter(city=city_filter)
                student_accounts = student_accounts.filter(city=city_filter)
    
    # Get available states and cities for filters
    states = set()
    cities = set()
    
    if zone_filter:
        # Collect states from all models for the selected zone
        states.update(
            leads.filter(zone=zone_filter).values_list('state', flat=True).distinct(),
            contacts.filter(zone=zone_filter).values_list('mailing_state', flat=True).distinct(),
            accounts.filter(zone=zone_filter).values_list('billing_state', flat=True).distinct(),
            students.filter(zone=zone_filter).values_list('state', flat=True).distinct(),
            student_accounts.filter(zone=zone_filter).values_list('state', flat=True).distinct()
        )
        
        if state_filter:
            # Collect cities from all models for the selected state and zone
            cities.update(
                leads.filter(zone=zone_filter, state=state_filter).values_list('city', flat=True).distinct(),
                contacts.filter(zone=zone_filter, mailing_state=state_filter).values_list('mailing_city', flat=True).distinct(),
                accounts.filter(zone=zone_filter, billing_state=state_filter).values_list('billing_city', flat=True).distinct(),
                students.filter(zone=zone_filter, state=state_filter).values_list('city', flat=True).distinct(),
                student_accounts.filter(zone=zone_filter, state=state_filter).values_list('city', flat=True).distinct()
            )
    
    # Remove None values and sort
    states = sorted(filter(None, states))
    cities = sorted(filter(None, cities))
    
    context = {
        'users': users,
        'leads': leads,
        'contacts': contacts,
        'accounts': accounts,
        'opportunities': opportunities,
        'students': students,
        'student_accounts': student_accounts,
        'search_query': search_query,
        'zone_filter': zone_filter,
        'state_filter': state_filter,
        'city_filter': city_filter,
        'status_filter': status_filter,
        'zone_choices': ZONE_CHOICES,
        'states': states,
        'cities': cities,
        'lead_status_choices': LEAD_STATUS_CHOICES,
        'student_status_choices': STUDENT_STATUS_CHOICES,
    }
    
    # If it's an AJAX request, return only the selection lists
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render(request, 'edtech_crm/assignment_panel.html', context)
    
    return render(request, 'edtech_crm/assignment_panel.html', context)

@login_required
def get_states(request):
    """API endpoint to get states for a selected zone"""
    zone = request.GET.get('zone')
    if not zone:
        return JsonResponse({'states': []})
    
    # Collect states from all models for the selected zone
    states = set()
    states.update(
        UniversityLead.objects.filter(zone=zone).values_list('state', flat=True).distinct(),
        UniversityContact.objects.filter(zone=zone).values_list('mailing_state', flat=True).distinct(),
        UniversityAccount.objects.filter(zone=zone).values_list('billing_state', flat=True).distinct(),
        Student.objects.filter(zone=zone).values_list('state', flat=True).distinct(),
        StudentAccount.objects.filter(zone=zone).values_list('state', flat=True).distinct()
    )
    
    # Remove None values and sort
    states = sorted(filter(None, states))
    return JsonResponse({'states': list(states)})

@login_required
def get_cities(request):
    """API endpoint to get cities for a selected state and zone"""
    state = request.GET.get('state')
    zone = request.GET.get('zone')
    if not state or not zone:
        return JsonResponse({'cities': []})
    
    # Collect cities from all models for the selected state and zone
    cities = set()
    cities.update(
        UniversityLead.objects.filter(zone=zone, state=state).values_list('city', flat=True).distinct(),
        UniversityContact.objects.filter(zone=zone, mailing_state=state).values_list('mailing_city', flat=True).distinct(),
        UniversityAccount.objects.filter(zone=zone, billing_state=state).values_list('billing_city', flat=True).distinct(),
        Student.objects.filter(zone=zone, state=state).values_list('city', flat=True).distinct(),
        StudentAccount.objects.filter(zone=zone, state=state).values_list('city', flat=True).distinct()
    )
    
    # Remove None values and sort
    cities = sorted(filter(None, cities))
    return JsonResponse({'cities': list(cities)})

# Import/Export Views for Contacts
@login_required
def import_contacts(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to import contacts.')
        return redirect('contact_list')
        
    if request.method == 'POST':
        form = ImportDataForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                file = request.FILES['file']
                if file.name.endswith('.xlsx'):
                    df = pd.read_excel(file)
                elif file.name.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    messages.error(request, 'Unsupported file format. Please upload an Excel (.xlsx) or CSV file.')
                    return redirect('import_contacts')
                
                for _, row in df.iterrows():
                    contact = UniversityContact(
                        first_name=row.get('first_name', ''),
                        last_name=row.get('last_name', ''),
                        university_name=row.get('university_name', ''),
                        title=row.get('title', ''),
                        email=row.get('email', ''),
                        phone=row.get('phone', ''),
                        mailing_street=row.get('mailing_street', ''),
                        mailing_city=row.get('mailing_city', ''),
                        mailing_state=row.get('mailing_state', ''),
                        mailing_zipcode=row.get('mailing_zipcode', ''),
                        mailing_country=row.get('mailing_country', ''),
                        contact_owner=request.user,
                    )
                    contact.save()
                
                messages.success(request, f'Successfully imported {len(df)} contacts.')
                return redirect('contact_list')
            
            except Exception as e:
                messages.error(request, f'Error importing data: {str(e)}')
                return redirect('import_contacts')
    else:
        form = ImportDataForm()
    
    return render(request, 'edtech_crm/import_form.html', {'form': form, 'model_type': 'Contacts'})

@login_required
def export_contacts(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to export contacts.')
        return redirect('contact_list')
        
    contacts = UniversityContact.objects.all()
    
    data = []
    for contact in contacts:
        data.append({
            'id': contact.id,
            'first_name': contact.first_name,
            'last_name': contact.last_name,
            'university_name': contact.university_name,
            'title': contact.title,
            'email': contact.email,
            'phone': contact.phone,
            'mailing_street': contact.mailing_street,
            'mailing_city': contact.mailing_city,
            'mailing_state': contact.mailing_state,
            'mailing_zipcode': contact.mailing_zipcode,
            'mailing_country': contact.mailing_country,
            'contact_owner': contact.contact_owner.username if contact.contact_owner else '',
            'created_at': contact.created_at,
            'updated_at': contact.updated_at,
        })
    
    df = pd.DataFrame(data)
    
    df['created_at'] = df['created_at'].dt.tz_localize(None)
    df['updated_at'] = df['updated_at'].dt.tz_localize(None)
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Contacts')
    
    output.seek(0)
    response = HttpResponse(output.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=university_contacts.xlsx'
    
    return response

# Import/Export Views for Accounts
@login_required
def import_accounts(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to import accounts.')
        return redirect('account_list')
        
    if request.method == 'POST':
        form = ImportDataForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                file = request.FILES['file']
                if file.name.endswith('.xlsx'):
                    df = pd.read_excel(file)
                elif file.name.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    messages.error(request, 'Unsupported file format. Please upload an Excel (.xlsx) or CSV file.')
                    return redirect('import_accounts')
                
                for _, row in df.iterrows():
                    account = UniversityAccount(
                        account_name=row.get('account_name', ''),
                        type=row.get('type', ''),
                        website=row.get('website', ''),
                        description=row.get('description', ''),
                        billing_street=row.get('billing_street', ''),
                        billing_city=row.get('billing_city', ''),
                        billing_state=row.get('billing_state', ''),
                        billing_zipcode=row.get('billing_zipcode', ''),
                        billing_country=row.get('billing_country', ''),
                        account_owner=request.user,
                    )
                    account.save()
                
                messages.success(request, f'Successfully imported {len(df)} accounts.')
                return redirect('account_list')
            
            except Exception as e:
                messages.error(request, f'Error importing data: {str(e)}')
                return redirect('import_accounts')
    else:
        form = ImportDataForm()
    
    return render(request, 'edtech_crm/import_form.html', {'form': form, 'model_type': 'Accounts'})

@login_required
def export_accounts(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to export accounts.')
        return redirect('account_list')
        
    accounts = UniversityAccount.objects.all()
    
    data = []
    for account in accounts:
        data.append({
            'id': account.id,
            'account_name': account.account_name,
            'type': account.type,
            'website': account.website,
            'description': account.description,
            'billing_street': account.billing_street,
            'billing_city': account.billing_city,
            'billing_state': account.billing_state,
            'billing_zipcode': account.billing_zipcode,
            'billing_country': account.billing_country,
            'account_owner': account.account_owner.username if account.account_owner else '',
            'created_at': account.created_at,
            'updated_at': account.updated_at,
        })
    
    df = pd.DataFrame(data)
    
    df['created_at'] = df['created_at'].dt.tz_localize(None)
    df['updated_at'] = df['updated_at'].dt.tz_localize(None)
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Accounts')
    
    output.seek(0)
    response = HttpResponse(output.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=university_accounts.xlsx'
    
    return response

# Import/Export Views for Opportunities
@login_required
def import_opportunities(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to import opportunities.')
        return redirect('opportunity_list')
        
    if request.method == 'POST':
        form = ImportDataForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                file = request.FILES['file']
                if file.name.endswith('.xlsx'):
                    df = pd.read_excel(file)
                elif file.name.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    messages.error(request, 'Unsupported file format. Please upload an Excel (.xlsx) or CSV file.')
                    return redirect('import_opportunities')
                
                for _, row in df.iterrows():
                    opportunity = UniversityOpportunity(
                        opportunity_name=row.get('opportunity_name', ''),
                        stage=row.get('stage', ''),
                        amount=row.get('amount', 0.0),
                        close_date=row.get('close_date'),
                        description=row.get('description', ''),
                        opportunity_owner=request.user,
                    )
                    opportunity.save()
                
                messages.success(request, f'Successfully imported {len(df)} opportunities.')
                return redirect('opportunity_list')
            
            except Exception as e:
                messages.error(request, f'Error importing data: {str(e)}')
                return redirect('import_opportunities')
    else:
        form = ImportDataForm()
    
    return render(request, 'edtech_crm/import_form.html', {'form': form, 'model_type': 'Opportunities'})

@login_required
def export_opportunities(request):
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to export opportunities.')
        return redirect('opportunity_list')
        
    opportunities = UniversityOpportunity.objects.all()
    
    data = []
    for opportunity in opportunities:
        data.append({
            'id': opportunity.id,
            'opportunity_name': opportunity.opportunity_name,
            'stage': opportunity.stage,
            'amount': opportunity.amount,
            'close_date': opportunity.close_date,
            'description': opportunity.description,
            'opportunity_owner': opportunity.opportunity_owner.username if opportunity.opportunity_owner else '',
            'created_at': opportunity.created_at,
            'updated_at': opportunity.updated_at,
        })
    
    df = pd.DataFrame(data)
    
    df['created_at'] = df['created_at'].dt.tz_localize(None)
    df['updated_at'] = df['updated_at'].dt.tz_localize(None)
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Opportunities')
    
    output.seek(0)
    response = HttpResponse(output.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=university_opportunities.xlsx'
    
    return response

# Student Views
@login_required
def student_list(request):
    if request.user.is_superuser:
        students = Student.objects.all()
    else:
        # Get the current user's roles
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        
        if not user_roles.exists():
            # If user has no roles, show only directly owned students
            students = Student.objects.filter(student_owner=request.user)
        else:
            # Start with directly owned students
            students_query = Q(student_owner=request.user)
            
            # For each role the user has
            for user_role in user_roles:
                # If user has a management role
                if user_role.role.name in ['regional_head', 'zonal_head', 'state_head', 'city_head']:
                    # Get subordinate roles
                    subordinate_roles = Role.objects.filter(parent_role=user_role.role)
                    
                    # Find users with those roles in user's territory
                    territory_query = Q()
                    if user_role.zone:
                        territory_query &= Q(user_roles__zone=user_role.zone)
                    if user_role.state:
                        territory_query &= Q(user_roles__state=user_role.state)
                    if user_role.city:
                        territory_query &= Q(user_roles__city=user_role.city)
                    
                    # Find subordinate users in the territory
                    subordinate_users = User.objects.filter(
                        user_roles__role__in=subordinate_roles,
                        user_roles__is_active=True
                    ).filter(territory_query).distinct()
                    
                    # Add students owned by subordinates
                    if subordinate_users.exists():
                        students_query |= Q(student_owner__in=subordinate_users)
                        
                    # For role-specific territory queries
                    if user_role.role.name == 'regional_head':
                        # Regional heads can see all students in their zones
                        if user_role.zone:
                            students_query |= Q(zone=user_role.zone)
                    
                    elif user_role.role.name == 'zonal_head':
                        # Zonal heads can see students in their zone
                        if user_role.zone:
                            students_query |= Q(zone=user_role.zone)
                    
                    elif user_role.role.name == 'state_head':
                        # State heads can see students in their state
                        if user_role.state and user_role.zone:
                            students_query |= Q(state=user_role.state, zone=user_role.zone)
                    
                    elif user_role.role.name == 'city_head':
                        # City heads can see students in their city
                        if user_role.city and user_role.state and user_role.zone:
                            students_query |= Q(
                                city=user_role.city, 
                                state=user_role.state, 
                                zone=user_role.zone
                            )
            
            # Apply the combined query
            students = Student.objects.filter(students_query).distinct()
    
    # Get search and filter parameters
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')
    university_filter = request.GET.get('university', '')
    
    # Apply search filter
    if search_query:
        students = students.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone_number__icontains=search_query)
        )
    
    # Apply status filter
    if status_filter:
        students = students.filter(status=status_filter)
    
    # Apply university filter
    if university_filter:
        students = students.filter(university_id=university_filter)
    
    # Get all universities for filter dropdown
    universities = UniversityAccount.objects.all()
    
    # Calculate student statistics
    total_students = students.count()
    prospect_students = students.filter(status='prospect').count()
    customer_students = students.filter(status='customer').count()
    closed_students = students.filter(status='closed').count()
    
    context = {
        'students': students,
        'search_query': search_query,
        'status_filter': status_filter,
        'university_filter': university_filter,
        'universities': universities,
        'total_students': total_students,
        'prospect_students': prospect_students,
        'customer_students': customer_students,
        'closed_students': closed_students,
    }
    
    return render(request, 'edtech_crm/student_list.html', context)

@login_required
def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    
    # Check if user is superuser or the student owner
    if request.user.is_superuser or student.student_owner == request.user:
        access_granted = True
    else:
        # Check if user is in a parent role that should have access
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        access_granted = False
        
        for user_role in user_roles:
            # If user has a management role
            if user_role.role.name in ['regional_head', 'zonal_head', 'state_head', 'city_head']:
                # Check if student is in the user's territory
                territory_match = True
                
                if user_role.zone and student.zone != user_role.zone:
                    territory_match = False
                
                if user_role.state and student.state != user_role.state:
                    territory_match = False
                
                if user_role.city and student.city != user_role.city:
                    territory_match = False
                
                # If in territory, check role hierarchy
                if territory_match:
                    if user_role.role.name == 'regional_head':
                        # Regional heads can see all students in their zones
                        access_granted = True
                        break
                    
                    elif user_role.role.name == 'zonal_head':
                        # Zonal heads can see all students in their zone except those 
                        # assigned to city/state heads
                        if student.student_owner:
                            owner_roles = UserRole.objects.filter(
                                user=student.student_owner,
                                role__name__in=['city_head', 'state_head'],
                                is_active=True
                            )
                            if not owner_roles.exists():
                                access_granted = True
                                break
                        else:
                            access_granted = True
                            break
                    
                    elif user_role.role.name == 'state_head':
                        # State heads can see students owned by them or their subordinates
                        if student.student_owner:
                            owner_roles = UserRole.objects.filter(
                                user=student.student_owner,
                                role__name='city_head',
                                is_active=True
                            )
                            if not owner_roles.exists():
                                access_granted = True
                                break
                        else:
                            access_granted = True
                            break
                            
    if not access_granted:
        raise PermissionDenied("You do not have permission to view this student.")
    
    return render(request, 'edtech_crm/student_detail.html', {'student': student})

@login_required
def student_create(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)
            student.student_owner = request.user
            student.save()
            messages.success(request, 'Student record created successfully!')
            return redirect('student_detail', pk=student.pk)
    else:
        form = StudentForm()
    
    return render(request, 'edtech_crm/student_form.html', {
        'form': form,
        'action': 'Create'
    })

@login_required
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    
    # Check if user is superuser or the student owner
    if request.user.is_superuser or student.student_owner == request.user:
        access_granted = True
    else:
        # Check if user is in a parent role that should have access
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        access_granted = False
        
        for user_role in user_roles:
            # If user has a management role
            if user_role.role.name in ['regional_head', 'zonal_head', 'state_head', 'city_head']:
                # Check if student is in the user's territory
                territory_match = True
                
                if user_role.zone and student.zone != user_role.zone:
                    territory_match = False
                
                if user_role.state and student.state != user_role.state:
                    territory_match = False
                
                if user_role.city and student.city != user_role.city:
                    territory_match = False
                
                # If in territory, check role hierarchy
                if territory_match:
                    if user_role.role.name == 'regional_head':
                        # Regional heads can edit all students in their zones
                        access_granted = True
                        break
                    
                    elif user_role.role.name == 'zonal_head':
                        # Zonal heads can edit all students in their zone except those 
                        # assigned to city/state heads
                        if student.student_owner:
                            owner_roles = UserRole.objects.filter(
                                user=student.student_owner,
                                role__name__in=['city_head', 'state_head'],
                                is_active=True
                            )
                            if not owner_roles.exists():
                                access_granted = True
                                break
                        else:
                            access_granted = True
                            break
                    
                    elif user_role.role.name == 'state_head':
                        # State heads can edit students owned by them or their subordinates
                        if student.student_owner:
                            owner_roles = UserRole.objects.filter(
                                user=student.student_owner,
                                role__name='city_head',
                                is_active=True
                            )
                            if not owner_roles.exists():
                                access_granted = True
                                break
                        else:
                            access_granted = True
                            break
    
    if not access_granted:
        raise PermissionDenied("You do not have permission to update this student.")
    
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student record updated successfully!')
            return redirect('student_detail', pk=student.pk)
    else:
        form = StudentForm(instance=student)
    
    return render(request, 'edtech_crm/student_form.html', {
        'form': form,
        'action': 'Update',
        'student': student
    })

@login_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    
    # Check if user is superuser or the student owner
    if request.user.is_superuser or student.student_owner == request.user:
        access_granted = True
    else:
        # Check if user is in a parent role that should have access
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        access_granted = False
        
        for user_role in user_roles:
            # Only Regional and Zonal heads should be able to delete students
            if user_role.role.name in ['regional_head', 'zonal_head']:
                # Check if student is in the user's territory
                territory_match = True
                
                if user_role.zone and student.zone != user_role.zone:
                    territory_match = False
                
                # If in territory, check role hierarchy
                if territory_match:
                    access_granted = True
                    break
    
    if not access_granted:
        raise PermissionDenied("You do not have permission to delete this student.")
    
    if request.method == 'POST':
        student.delete()
        messages.success(request, 'Student record deleted successfully!')
        return redirect('student_list')
    
    return render(request, 'edtech_crm/student_delete.html', {'student': student})

# Student Account Views
@login_required
def student_account_list(request):
    if request.user.is_superuser:
        accounts = StudentAccount.objects.all()
    else:
        accounts = StudentAccount.objects.filter(account_owner=request.user)
    
    # Get search and filter parameters
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')
    payment_mode_filter = request.GET.get('payment_mode', '')
    
    # Apply search filter
    if search_query:
        accounts = accounts.filter(
            Q(account_name__icontains=search_query) |
            Q(student__email__icontains=search_query) |
            Q(student__phone_number__icontains=search_query)
        )
    
    # Apply status filter
    if status_filter:
        accounts = accounts.filter(status=status_filter)
    
    # Apply payment mode filter
    if payment_mode_filter:
        accounts = accounts.filter(payment_mode=payment_mode_filter)
    
    # Calculate account statistics
    total_accounts = accounts.count()
    full_payment_accounts = accounts.filter(payment_mode='full').count()
    emi_accounts = accounts.filter(payment_mode='emi').count()
    active_accounts = accounts.filter(status='customer').count()
    
    context = {
        'accounts': accounts,
        'search_query': search_query,
        'status_filter': status_filter,
        'payment_mode_filter': payment_mode_filter,
        'total_accounts': total_accounts,
        'full_payment_accounts': full_payment_accounts,
        'emi_accounts': emi_accounts,
        'active_accounts': active_accounts,
    }
    
    return render(request, 'edtech_crm/student_account_list.html', context)

@login_required
def student_account_detail(request, pk):
    if request.user.is_superuser:
        account = get_object_or_404(StudentAccount, pk=pk)
    else:
        account = get_object_or_404(StudentAccount, pk=pk, account_owner=request.user)
    
    context = {
        'account': account,
        'today': timezone.now().date()
    }
    
    return render(request, 'edtech_crm/student_account_detail.html', context)

@login_required
def student_account_create(request):
    if request.method == 'POST':
        form = StudentAccountForm(request.POST)
        if form.is_valid():
            account = form.save(commit=False)
            account.account_owner = request.user
            
            # Copy address from student
            student = form.cleaned_data['student']
            account.street = student.street
            account.city = student.city
            account.state = student.state
            account.zone = student.zone
            account.country = student.country
            account.industry = student.industry
            
            account.save()
            messages.success(request, 'Student account created successfully!')
            return redirect('student_account_detail', pk=account.pk)
    else:
        # Pre-select student if coming from student detail page
        student_id = request.GET.get('student_id')
        initial = {'student': student_id} if student_id else {}
        form = StudentAccountForm(initial=initial)
    
    return render(request, 'edtech_crm/student_account_form.html', {
        'form': form,
        'action': 'Create'
    })

@login_required
def student_account_update(request, pk):
    if request.user.is_superuser:
        account = get_object_or_404(StudentAccount, pk=pk)
    else:
        account = get_object_or_404(StudentAccount, pk=pk, account_owner=request.user)
    
    if request.method == 'POST':
        form = StudentAccountForm(request.POST, instance=account)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student account updated successfully!')
            return redirect('student_account_detail', pk=account.pk)
    else:
        form = StudentAccountForm(instance=account)
    
    return render(request, 'edtech_crm/student_account_form.html', {
        'form': form,
        'account': account,
        'action': 'Update'
    })

@login_required
def student_account_delete(request, pk):
    if request.user.is_superuser:
        account = get_object_or_404(StudentAccount, pk=pk)
    else:
        account = get_object_or_404(StudentAccount, pk=pk, account_owner=request.user)
    
    if request.method == 'POST':
        account.delete()
        messages.success(request, 'Student account deleted successfully!')
        return redirect('student_account_list')
    
    return render(request, 'edtech_crm/student_account_delete.html', {'account': account})

@login_required
def role_list(request):
    """View to list all roles and their hierarchy"""
    roles = Role.objects.all().order_by('name')
    
    # Create a dictionary to store role hierarchy
    role_hierarchy = {}
    top_level_roles = []
    
    # First, initialize the hierarchy dictionary with empty lists for all roles
    for role in roles:
        role_hierarchy[role] = []
    
    # Then build the hierarchy by adding children to their parents
    for role in roles:
        if role.parent_role:
            role_hierarchy[role.parent_role].append(role)
        else:
            top_level_roles.append(role)
    
    # Sort top level roles and children
    top_level_roles.sort(key=lambda x: x.name)
    for parent in role_hierarchy:
        role_hierarchy[parent].sort(key=lambda x: x.name)
    
    context = {
        'roles': roles,
        'role_hierarchy': role_hierarchy,
        'top_level_roles': top_level_roles,
    }
    return render(request, 'edtech_crm/role_list.html', context)

@login_required
def role_create(request):
    """View to create a new role"""
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to create roles.')
        return redirect('role_list')
    
    if request.method == 'POST':
        form = RoleForm(request.POST)
        if form.is_valid():
            role = form.save()
            messages.success(request, f'Role "{role.get_name_display()}" created successfully.')
            return redirect('role_list')
    else:
        form = RoleForm()
    
    return render(request, 'edtech_crm/role_form.html', {
        'form': form,
        'title': 'Create Role'
    })

@login_required
def role_edit(request, pk):
    """View to edit an existing role"""
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to edit roles.')
        return redirect('role_list')
    
    role = get_object_or_404(Role, pk=pk)
    
    if request.method == 'POST':
        form = RoleForm(request.POST, instance=role)
        if form.is_valid():
            role = form.save()
            messages.success(request, f'Role "{role.get_name_display()}" updated successfully.')
            return redirect('role_list')
    else:
        form = RoleForm(instance=role)
    
    return render(request, 'edtech_crm/role_form.html', {
        'form': form,
        'title': 'Edit Role',
        'role': role
    })

@login_required
def role_delete(request, pk):
    """View to delete a role"""
    if not request.user.is_superuser:
        messages.error(request, 'You do not have permission to delete roles.')
        return redirect('role_list')
    
    role = get_object_or_404(Role, pk=pk)
    
    if request.method == 'POST':
        role_name = role.get_name_display()
        role.delete()
        messages.success(request, f'Role "{role_name}" deleted successfully.')
        return redirect('role_list')
    
    return render(request, 'edtech_crm/role_confirm_delete.html', {'role': role})

@login_required
def user_role_list(request):
    """View to list all user roles"""
    if request.user.is_superuser:
        user_roles = UserRole.objects.all()
    else:
        # Get user's roles
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        subordinate_roles = []
        
        # Get subordinates for each of user's roles
        for user_role in user_roles:
            subordinate_roles.extend(user_role.get_subordinates())
        
        # Combine user's roles with subordinate roles
        user_roles = UserRole.objects.filter(
            id__in=[role.id for role in user_roles] + 
                   [role.id for role in subordinate_roles]
        ).distinct()
    
    context = {
        'user_roles': user_roles,
    }
    return render(request, 'edtech_crm/user_role_list.html', context)

@login_required
def user_role_create(request):
    """View to assign a role to a user"""
    if not request.user.is_superuser and not UserRole.objects.filter(user=request.user, is_active=True).exists():
        messages.error(request, 'You do not have permission to assign roles.')
        return redirect('user_role_list')
    
    if request.method == 'POST':
        form = UserRoleForm(request.POST, user=request.user)
        if form.is_valid():
            # Get states and cities from the form
            states = request.POST.getlist('states[]')
            cities = request.POST.getlist('cities[]')
            
            # Print debug info
            print(f"Form is valid. Received states: {states}, cities: {cities}")
            
            # Create the first user role
            user_role = form.save(commit=False)
            user_role.assigned_by = request.user
            
            # Check if we need to handle multiple assignments
            has_multiple_states = states and len(states) > 1
            has_multiple_cities = cities and len(cities) > 1
            
            # Handle different assignment scenarios
            if not states or not states[0].strip():
                # No states provided, just save the main record as is
                user_role.save()
                messages.success(request, f'Role assigned to {user_role.user.get_full_name()} successfully.')
            elif has_multiple_cities:
                # Multiple cities provided, create separate records for each city
                user_role.state = states[0].strip()
                
                # First city goes to the main record
                if cities and cities[0].strip():
                    user_role.city = cities[0].strip()
                
                user_role.save()
                
                # Create additional records for each additional city
                created_count = 1  # Count main record
                for city in cities[1:]:
                    if city.strip():  # Skip empty cities
                        UserRole.objects.create(
                            user=user_role.user,
                            role=user_role.role,
                            zone=user_role.zone,
                            state=user_role.state,
                            city=city.strip(),
                            is_active=True,
                            assigned_by=request.user
                        )
                        created_count += 1
                
                messages.success(request, f'{created_count} role assignments created for {user_role.user.get_full_name()} with multiple cities successfully.')
            elif has_multiple_states:
                # Multiple states but single city, create separate records for each state
                user_role.state = states[0].strip()
                user_role.save()
                
                # Create additional role records for each additional state
                created_count = 1  # Count main record
                for state in states[1:]:
                    if state.strip():  # Skip empty states
                        # Create new role with same data but different state
                        UserRole.objects.create(
                            user=user_role.user,
                            role=user_role.role,
                            zone=user_role.zone,
                            state=state.strip(),
                            city=user_role.city,
                            is_active=True,
                            assigned_by=request.user
                        )
                        created_count += 1
                
                messages.success(request, f'{created_count} role assignments created for {user_role.user.get_full_name()} with multiple states successfully.')
            else:
                # Single state and single city
                user_role.state = states[0].strip()
                if cities and cities[0].strip():
                    user_role.city = cities[0].strip()
                user_role.save()
                messages.success(request, f'Role assigned to {user_role.user.get_full_name()} successfully.')
            
            return redirect('user_role_list')
        else:
            print(f"Form is invalid. Errors: {form.errors}")
            messages.error(request, f'Please correct the errors in the form: {form.errors}')
    else:
        form = UserRoleForm(user=request.user)
    
    return render(request, 'edtech_crm/user_role_form.html', {
        'form': form,
        'title': 'Assign Role'
    })

@login_required
def user_role_edit(request, pk):
    """View to edit a user role assignment"""
    user_role = get_object_or_404(UserRole, pk=pk)
    
    # Check if user has permission to edit this role
    if not request.user.is_superuser:
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        has_permission = False
        for role in user_roles:
            if role.can_manage_user(user_role):
                has_permission = True
                break
        if not has_permission:
            messages.error(request, 'You do not have permission to edit this role assignment.')
            return redirect('user_role_list')
    
    if request.method == 'POST':
        form = UserRoleForm(request.POST, instance=user_role, user=request.user)
        if form.is_valid():
            # Get states and cities from the form
            states = request.POST.getlist('states[]')
            cities = request.POST.getlist('cities[]')
            
            # Update the current user role
            user_role = form.save(commit=False)
            
            # If states exist, set the first state for this record
            if states and states[0].strip():
                user_role.state = states[0].strip()
            
            # If cities exist, set the first city for this record
            if cities and cities[0].strip():
                user_role.city = cities[0].strip()
            
            user_role.save()
            
            # Get user's existing roles with same role and zone
            same_role_assignments = UserRole.objects.filter(
                user=user_role.user,
                role=user_role.role,
                zone=user_role.zone
            ).exclude(pk=user_role.pk)
            
            # Delete existing role assignments
            same_role_assignments.delete()
            
            # Create additional roles for other states (when multiple states but single city)
            if len(cities) <= 1:
                for state in states[1:]:
                    if state.strip():  # Skip empty states
                        # Create new role with same data but different state
                        UserRole.objects.create(
                            user=user_role.user,
                            role=user_role.role,
                            zone=user_role.zone,
                            state=state.strip(),
                            city=user_role.city,
                            is_active=True,
                            assigned_by=request.user
                        )
            
            # Create additional roles for other cities (when single state but multiple cities)
            if len(states) <= 1 and len(cities) > 1:
                for city in cities[1:]:
                    if city.strip():  # Skip empty cities
                        # Create new role with same data but different city
                        UserRole.objects.create(
                            user=user_role.user,
                            role=user_role.role,
                            zone=user_role.zone,
                            state=user_role.state,
                            city=city.strip(),
                            is_active=True,
                            assigned_by=request.user
                        )
            
            messages.success(request, f'Role assignment(s) updated successfully.')
            return redirect('user_role_list')
    else:
        form = UserRoleForm(instance=user_role, user=request.user)
        
        # Get other states and cities for this user with same role and zone
        same_role_assignments = UserRole.objects.filter(
            user=user_role.user,
            role=user_role.role,
            zone=user_role.zone
        ).exclude(pk=user_role.pk)
        
        # Get distinct cities
        other_cities = []
        if user_role.state:
            other_cities = list(same_role_assignments.filter(
                state=user_role.state
            ).values_list('city', flat=True).distinct())
    
    return render(request, 'edtech_crm/user_role_form.html', {
        'form': form,
        'other_states': [ur.state for ur in same_role_assignments] if 'same_role_assignments' in locals() else [],
        'other_cities': other_cities if 'other_cities' in locals() else [],
        'title': 'Edit Role Assignment'
    })

@login_required
def user_role_delete(request, pk):
    """View to delete a user role assignment"""
    user_role = get_object_or_404(UserRole, pk=pk)
    
    # Check if user has permission to delete this role
    if not request.user.is_superuser:
        user_roles = UserRole.objects.filter(user=request.user, is_active=True)
        has_permission = False
        for role in user_roles:
            if role.can_manage_user(user_role):
                has_permission = True
                break
        if not has_permission:
            messages.error(request, 'You do not have permission to delete this role assignment.')
            return redirect('user_role_list')
    
    if request.method == 'POST':
        user_name = user_role.user.get_full_name()
        role_name = user_role.role.get_name_display()
        user_role.delete()
        messages.success(request, f'Role "{role_name}" removed from {user_name} successfully.')
        return redirect('user_role_list')
    
    return render(request, 'edtech_crm/user_role_confirm_delete.html', {'user_role': user_role})

def user_has_lead_access(user, lead):
    """Helper function to check if a user has access to a lead based on role and location"""
    # Admin or owner always has access
    if user.is_superuser or user.is_staff or user == lead.lead_owner:
        return True
    
    # Check if user has roles that give access to this lead
    user_roles = UserRole.objects.filter(user=user, is_active=True)
    
    for user_role in user_roles:
        # Zone heads can see all leads in their zone
        if user_role.zone and lead.zone and user_role.zone.lower() == lead.zone.lower() and not user_role.state and not user_role.city:
            return True
            
        # State heads can see all leads in their state (assuming same zone)
        if (user_role.zone and lead.zone and user_role.zone.lower() == lead.zone.lower() and
            user_role.state and lead.state and user_role.state.lower() == lead.state.lower() and 
            not user_role.city):
            return True
            
        # City heads can see only their city leads
        if (user_role.zone and lead.zone and user_role.zone.lower() == lead.zone.lower() and
            user_role.state and lead.state and user_role.state.lower() == lead.state.lower() and
            user_role.city and lead.city and user_role.city.lower() == lead.city.lower()):
            return True
            
        # Regional Head has access to all leads
        if user_role.role.name == 'regional_head':
            return True
    
    return False 
