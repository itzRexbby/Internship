from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from edtech_crm.models import UniversityLead, UniversityContact, UniversityAccount, UniversityOpportunity

class Command(BaseCommand):
    help = 'Assign leads, contacts, accounts, and opportunities to users based on their IDs'

    def add_arguments(self, parser):
        parser.add_argument('--user_id', type=int, help='User ID to assign items to')
        parser.add_argument('--lead_ids', nargs='+', type=int, help='List of lead IDs to assign')
        parser.add_argument('--contact_ids', nargs='+', type=int, help='List of contact IDs to assign')
        parser.add_argument('--account_ids', nargs='+', type=int, help='List of account IDs to assign')
        parser.add_argument('--opportunity_ids', nargs='+', type=int, help='List of opportunity IDs to assign')

    def handle(self, *args, **options):
        user_id = options['user_id']
        lead_ids = options['lead_ids']
        contact_ids = options['contact_ids']
        account_ids = options['account_ids']
        opportunity_ids = options['opportunity_ids']

        try:
            user = User.objects.get(id=user_id)
            self.stdout.write(self.style.SUCCESS(f'User found: {user.username}'))
        except User.DoesNotExist:
            self.stdout.write(self.style.ERROR('User not found'))
            return

        if lead_ids:
            leads = UniversityLead.objects.filter(id__in=lead_ids)
            leads.update(lead_owner=user)
            self.stdout.write(self.style.SUCCESS(f'Assigned {leads.count()} leads to {user.username}'))

        if contact_ids:
            contacts = UniversityContact.objects.filter(id__in=contact_ids)
            contacts.update(contact_owner=user)
            self.stdout.write(self.style.SUCCESS(f'Assigned {contacts.count()} contacts to {user.username}'))

        if account_ids:
            accounts = UniversityAccount.objects.filter(id__in=account_ids)
            accounts.update(account_owner=user)
            self.stdout.write(self.style.SUCCESS(f'Assigned {accounts.count()} accounts to {user.username}'))

        if opportunity_ids:
            opportunities = UniversityOpportunity.objects.filter(id__in=opportunity_ids)
            opportunities.update(opportunity_owner=user)
            self.stdout.write(self.style.SUCCESS(f'Assigned {opportunities.count()} opportunities to {user.username}'))

        self.stdout.write(self.style.SUCCESS('Assignment complete')) 