from django.core.management.base import BaseCommand
from edtech_crm.models import UniversityLead
import pandas as pd

class Command(BaseCommand):
    help = 'Converts "nan" values in the database to blank or default values'

    def handle(self, *args, **options):
        # Get all leads
        leads = UniversityLead.objects.all()
        self.stdout.write(f"Found {leads.count()} leads to process")
        
        updated_count = 0
        
        # Process each lead
        for lead in leads:
            updated = False
            
            # Check and fix string fields
            string_fields = ['first_name', 'last_name', 'university_name', 'title', 'website',
                            'description', 'lead_status', 'phone', 'email', 'street',
                            'city', 'zipcode', 'state', 'country', 'industry',
                            'lead_source', 'zone']
                            
            # Process each string field
            for field in string_fields:
                value = getattr(lead, field)
                if isinstance(value, str) and (value.lower() == 'nan' or value.lower() == 'null'):
                    setattr(lead, field, '')
                    updated = True
                    self.stdout.write(f"  - Fixed {field} in lead {lead.id}")
            
            # Set defaults for required fields if they're empty or 'nan'
            if not lead.lead_status or lead.lead_status.lower() == 'nan':
                lead.lead_status = 'New'
                updated = True
                self.stdout.write(f"  - Fixed lead_status in lead {lead.id}")
                
            if not lead.lead_source or lead.lead_source.lower() == 'nan':
                lead.lead_source = 'None'
                updated = True
                self.stdout.write(f"  - Fixed lead_source in lead {lead.id}")
                
            if not lead.zone or lead.zone.lower() == 'nan':
                lead.zone = 'None'
                updated = True
                self.stdout.write(f"  - Fixed zone in lead {lead.id}")
            
            # Save if any fields were updated
            if updated:
                lead.save()
                updated_count += 1
        
        self.stdout.write(self.style.SUCCESS(f"Successfully fixed 'nan' values in {updated_count} leads")) 