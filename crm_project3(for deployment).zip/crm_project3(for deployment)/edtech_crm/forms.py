from django import forms
from .models import UniversityLead, UniversityContact, UniversityAccount, UniversityOpportunity, Student, StudentAccount, Role, UserRole
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Row, Column, Fieldset, HTML, Div

class UniversityLeadForm(forms.ModelForm):
    meeting_schedule = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        required=False
    )
    
    class Meta:
        model = UniversityLead
        fields = [
            'first_name', 'last_name', 'university_name', 'title', 'website',
            'description', 'lead_status', 'lead_source', 'phone', 'email',
            'zipcode', 'city', 'state', 'zone', 'next_step', 'meeting_schedule'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'next_step': forms.Textarea(attrs={'rows': 2, 'placeholder': 'What is the next action to take with this lead?'}),
        }
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        
        # Make first_name, last_name, and title not required initially
        # They will be validated in the clean method if lead_status is 'Qualified'
        self.fields['first_name'].required = False
        self.fields['last_name'].required = False
        self.fields['title'].required = False
        
        # Add help text for location fields
        self.fields['zone'].help_text = "Selecting a zone will assign the lead to a Zonal Head"
        self.fields['state'].help_text = "Selecting both zone and state will assign the lead to a State Head"
        self.fields['city'].help_text = "Selecting zone, state, and city will assign the lead to a City Head"
        
        self.helper.layout = Layout(
            Fieldset(
                'Basic Information',
                Row(
                    Column('first_name', css_class='form-group col-md-6 mb-0'),
                    Column('last_name', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('university_name', css_class='form-group col-md-6 mb-0'),
                    Column('title', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('website', css_class='form-group col-md-12 mb-0'),
                    css_class='form-row'
                ),
                'description',
            ),
            Fieldset(
                'Lead Status',
                Row(
                    Column('lead_status', css_class='form-group col-md-6 mb-0'),
                    Column('lead_source', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Fieldset(
                'Location Information',
                HTML("""
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <strong>Automatic Assignment Rules:</strong>
                        <ul class="mb-0">
                            <li>Zone only → Assigned to Zonal Head</li>
                            <li>Zone + State → Assigned to State Head</li>
                            <li>Zone + State + City → Assigned to City Head</li>
                        </ul>
                    </div>
                """),
                Row(
                    Column('zone', css_class='form-group col-md-4 mb-0'),
                    Column('state', css_class='form-group col-md-4 mb-0'),
                    Column('city', css_class='form-group col-md-4 mb-0'),
                    css_class='form-row'
                ),
            ),
            Fieldset(
                'Contact Information',
                Row(
                    Column('phone', css_class='form-group col-md-6 mb-0'),
                    Column('email', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('zipcode', css_class='form-group col-md-12 mb-0'),
                    css_class='form-row'
                ),
            ),
            Fieldset(
                'Follow-up Information',
                Row(
                    Column('next_step', css_class='form-group col-md-12 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('meeting_schedule', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Submit('submit', 'Save', css_class='btn btn-primary mt-3')
        )

    def clean(self):
        cleaned_data = super().clean()
        lead_status = cleaned_data.get('lead_status')
        
        # If lead is being qualified, make first_name, last_name, and title required
        if lead_status == 'Qualified':
            first_name = cleaned_data.get('first_name')
            last_name = cleaned_data.get('last_name')
            title = cleaned_data.get('title')
            
            if not first_name:
                self.add_error('first_name', 'First name is required when qualifying a lead.')
            
            if not last_name:
                self.add_error('last_name', 'Last name is required when qualifying a lead.')
            
            if not title:
                self.add_error('title', 'Title is required when qualifying a lead.')
        
        return cleaned_data


class UniversityContactForm(forms.ModelForm):
    class Meta:
        model = UniversityContact
        exclude = ['created_at', 'updated_at', 'user']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        
        # Hide contact_owner field for non-admin users
        if not user or not user.is_superuser:
            if 'contact_owner' in self.fields:
                del self.fields['contact_owner']
        
        self.helper.layout = Layout(
            Fieldset(
                'Basic Information',
                Row(
                    Column('first_name', css_class='form-group col-md-6 mb-0'),
                    Column('last_name', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('university_name', css_class='form-group col-md-6 mb-0'),
                    Column('title', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('reports_to', css_class='form-group col-md-12 mb-0'),
                    css_class='form-row'
                ),
                'description',
            ),
            Fieldset(
                'Contact Information',
                Row(
                    Column('phone', css_class='form-group col-md-6 mb-0'),
                    Column('email', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Fieldset(
                'Mailing Address',
                'mailing_street',
                Row(
                    Column('mailing_city', css_class='form-group col-md-6 mb-0'),
                    Column('mailing_state', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('mailing_zipcode', css_class='form-group col-md-6 mb-0'),
                    Column('mailing_country', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Submit('submit', 'Save', css_class='btn btn-primary mt-3')
        )


class UniversityAccountForm(forms.ModelForm):
    class Meta:
        model = UniversityAccount
        exclude = ['created_at', 'updated_at', 'user']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        
        # Hide account_owner field for non-admin users
        if not user or not user.is_superuser:
            if 'account_owner' in self.fields:
                del self.fields['account_owner']
        
        self.helper.layout = Layout(
            Fieldset(
                'Basic Information',
                Row(
                    Column('account_name', css_class='form-group col-md-6 mb-0'),
                    Column('website', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('type', css_class='form-group col-md-6 mb-0'),
                    Column('parent_account', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                'description',
            ),
            Fieldset(
                'Billing Address',
                'billing_street',
                Row(
                    Column('billing_city', css_class='form-group col-md-6 mb-0'),
                    Column('billing_state', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('billing_zipcode', css_class='form-group col-md-6 mb-0'),
                    Column('billing_country', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Fieldset(
                'Shipping Address',
                'shipping_street',
                Row(
                    Column('shipping_city', css_class='form-group col-md-6 mb-0'),
                    Column('shipping_state', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('shipping_zipcode', css_class='form-group col-md-6 mb-0'),
                    Column('shipping_country', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Submit('submit', 'Save', css_class='btn btn-primary mt-3')
        )


class UniversityOpportunityForm(forms.ModelForm):
    class Meta:
        model = UniversityOpportunity
        exclude = ['created_at', 'updated_at', 'open_date', 'user']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'closed_date': forms.DateInput(attrs={'type': 'date'}),
            'amount': forms.NumberInput(attrs={'step': '0.01', 'min': '0', 'class': 'form-control'}),
        }
    
    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is not None and amount < 0:
            raise forms.ValidationError("Amount cannot be negative")
        return amount
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        
        # Hide opportunity_owner field for non-admin users
        if not user or not user.is_superuser:
            if 'opportunity_owner' in self.fields:
                del self.fields['opportunity_owner']
        
        self.helper.layout = Layout(
            Fieldset(
                'Basic Information',
                Row(
                    Column('opportunity_name', css_class='form-group col-md-6 mb-0'),
                    Column('university_name', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('amount', css_class='form-group col-md-6 mb-0'),
                    Column('closed_date', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                'description',
            ),
            Fieldset(
                'Opportunity Stage and Probability',
                Row(
                    Column('stage', css_class='form-group col-md-6 mb-0'),
                    Column('probability', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
                Row(
                    Column('forecast_category', css_class='form-group col-md-6 mb-0'),
                    Column('next_step', css_class='form-group col-md-6 mb-0'),
                    css_class='form-row'
                ),
            ),
            Submit('submit', 'Save', css_class='btn btn-primary mt-3')
        )


class ImportDataForm(forms.Form):
    file = forms.FileField(
        label='Select a file',
        help_text='Allowed file types: .xlsx, .csv'
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.form_enctype = 'multipart/form-data'
        self.helper.layout = Layout(
            'file',
            Submit('submit', 'Import', css_class='btn btn-primary mt-3')
        )


class StudentForm(forms.ModelForm):
    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    meeting_schedule = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        required=False
    )

    class Meta:
        model = Student
        fields = [
            'first_name', 'last_name', 'gender', 'email', 'phone_number',
            'date_of_birth', 'university', 'industry', 'street', 'city', 'state',
            'zone', 'country', 'status', 'description', 'next_step',
            'meeting_schedule'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'next_step': forms.Textarea(attrs={'rows': 3}),
        }


class StudentAccountForm(forms.ModelForm):
    enrollment_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    completion_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )

    class Meta:
        model = StudentAccount
        fields = [
            'student', 'description', 'payment_amount', 'payment_mode',
            'emi_months', 'enrollment_date', 'completion_date', 'status'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # If this is an existing instance, disable student field
        if self.instance.pk:
            self.fields['student'].disabled = True
        
        # Show/hide EMI months based on payment mode
        self.fields['emi_months'].required = False
        if self.instance.payment_mode != 'emi':
            self.fields['emi_months'].widget = forms.HiddenInput()

    def clean(self):
        cleaned_data = super().clean()
        payment_mode = cleaned_data.get('payment_mode')
        emi_months = cleaned_data.get('emi_months')
        
        if payment_mode == 'emi' and not emi_months:
            raise forms.ValidationError('EMI months is required for EMI payment mode')
        
        enrollment_date = cleaned_data.get('enrollment_date')
        completion_date = cleaned_data.get('completion_date')
        
        if enrollment_date and completion_date and enrollment_date > completion_date:
            raise forms.ValidationError('Enrollment date cannot be later than completion date')
        
        return cleaned_data


class RoleForm(forms.ModelForm):
    class Meta:
        model = Role
        fields = ['name', 'parent_role', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            # Exclude self and child roles from parent role choices to prevent circular relationships
            self.fields['parent_role'].queryset = Role.objects.exclude(
                pk__in=Role.objects.filter(
                    pk__in=Role.objects.filter(parent_role=self.instance).values_list('id', flat=True)
                ).values_list('id', flat=True)
            ).exclude(pk=self.instance.pk)


class UserRoleForm(forms.ModelForm):
    class Meta:
        model = UserRole
        fields = ['user', 'role', 'zone', 'state', 'city']
        # We keep state and city fields in the form for initial value but they will be handled specially

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Add help text for state and city fields
        self.fields['state'].help_text = 'If more states need to be assigned, use the "+" button'
        self.fields['city'].help_text = 'If more cities need to be assigned, use the "+" button'
        
        if user and not user.is_superuser:
            user_roles = UserRole.objects.filter(user=user, is_active=True)
            allowed_roles = set()
            
            for user_role in user_roles:
                # Get subordinate roles based on hierarchy
                subordinate_roles = Role.objects.filter(parent_role=user_role.role)
                allowed_roles.update(subordinate_roles)
            
            self.fields['role'].queryset = Role.objects.filter(pk__in=[role.pk for role in allowed_roles])
            
            # Filter location fields based on user's highest role
            highest_role = user_roles.order_by('role__name').first()
            if highest_role:
                if highest_role.city:
                    self.fields['zone'].initial = highest_role.zone
                    self.fields['zone'].widget.attrs['readonly'] = True
                    self.fields['state'].initial = highest_role.state
                    self.fields['state'].widget.attrs['readonly'] = True
                    self.fields['city'].initial = highest_role.city
                    self.fields['city'].widget.attrs['readonly'] = True
                elif highest_role.state:
                    self.fields['zone'].initial = highest_role.zone
                    self.fields['zone'].widget.attrs['readonly'] = True
                    self.fields['state'].initial = highest_role.state
                    self.fields['state'].widget.attrs['readonly'] = True
                elif highest_role.zone:
                    self.fields['zone'].initial = highest_role.zone
                    self.fields['zone'].widget.attrs['readonly'] = True

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get('role')
        zone = cleaned_data.get('zone')
        state = cleaned_data.get('state')
        city = cleaned_data.get('city')

        # Validate location hierarchy
        if role:
            if role.name == 'city_head' and not city:
                raise forms.ValidationError('City Head must be assigned to a specific city')
            elif role.name == 'state_head' and not state:
                raise forms.ValidationError('State Head must be assigned to a specific state')
            elif role.name == 'zonal_head' and not zone:
                raise forms.ValidationError('Zonal Head must be assigned to a specific zone')

        # Validate location dependencies
        if city and not state:
            raise forms.ValidationError('State is required when specifying a city')
        if state and not zone:
            raise forms.ValidationError('Zone is required when specifying a state')

        return cleaned_data 