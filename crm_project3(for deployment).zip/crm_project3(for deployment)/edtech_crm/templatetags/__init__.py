# This file is intentionally empty
# It makes the templatetags directory a proper Python package 