from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    # Redirect root CRM URL to dashboard
    path('', login_required(views.dashboard), name='dashboard'),
    
    # Student URLs
    path('students/', views.student_list, name='student_list'),
    path('students/create/', views.student_create, name='student_create'),
    path('students/<int:pk>/update/', views.student_update, name='student_update'),
    path('students/<int:pk>/delete/', views.student_delete, name='student_delete'),
    path('students/<int:pk>/', views.student_detail, name='student_detail'),
    
    # Student Account URLs
    path('student-accounts/', views.student_account_list, name='student_account_list'),
    path('student-accounts/create/', views.student_account_create, name='student_account_create'),
    path('student-accounts/<int:pk>/update/', views.student_account_update, name='student_account_update'),
    path('student-accounts/<int:pk>/delete/', views.student_account_delete, name='student_account_delete'),
    path('student-accounts/<int:pk>/', views.student_account_detail, name='student_account_detail'),
    
    # Lead URLs
    path('leads/', views.lead_list, name='lead_list'),
    path('leads/create/', views.lead_create, name='lead_create'),
    path('leads/<int:pk>/update/', views.lead_update, name='lead_update'),
    path('leads/<int:pk>/delete/', views.lead_delete, name='lead_delete'),
    path('leads/<int:pk>/', views.lead_detail, name='lead_detail'),
    path('leads/import/', views.import_leads, name='import_leads'),
    path('leads/export/', views.export_leads, name='export_leads'),
    
    # Contact URLs
    path('contacts/', views.contact_list, name='contact_list'),
    path('contacts/create/', views.contact_create, name='contact_create'),
    path('contacts/<int:pk>/update/', views.contact_update, name='contact_update'),
    path('contacts/<int:pk>/delete/', views.contact_delete, name='contact_delete'),
    path('contacts/<int:pk>/', views.contact_detail, name='contact_detail'),
    path('contacts/import/', views.import_contacts, name='import_contacts'),
    path('contacts/export/', views.export_contacts, name='export_contacts'),
    
    # Account URLs
    path('accounts/', views.account_list, name='account_list'),
    path('accounts/create/', views.account_create, name='account_create'),
    path('accounts/<int:pk>/update/', views.account_update, name='account_update'),
    path('accounts/<int:pk>/delete/', views.account_delete, name='account_delete'),
    path('accounts/<int:pk>/', views.account_detail, name='account_detail'),
    path('accounts/import/', views.import_accounts, name='import_accounts'),
    path('accounts/export/', views.export_accounts, name='export_accounts'),
    
    # Opportunity URLs
    path('opportunities/', views.opportunity_list, name='opportunity_list'),
    path('opportunities/create/', views.opportunity_create, name='opportunity_create'),
    path('opportunities/<int:pk>/update/', views.opportunity_update, name='opportunity_update'),
    path('opportunities/<int:pk>/delete/', views.opportunity_delete, name='opportunity_delete'),
    path('opportunities/<int:pk>/', views.opportunity_detail, name='opportunity_detail'),
    path('opportunities/import/', views.import_opportunities, name='import_opportunities'),
    path('opportunities/export/', views.export_opportunities, name='export_opportunities'),
    
    # Assignment Panel URL
    path('admin/assignment-panel/', views.assignment_panel, name='assignment_panel'),
    path('api/states/', views.get_states, name='get_states'),
    path('api/cities/', views.get_cities, name='get_cities'),
    
    # Role Management URLs
    path('roles/', views.role_list, name='role_list'),
    path('roles/create/', views.role_create, name='role_create'),
    path('roles/<int:pk>/edit/', views.role_edit, name='role_edit'),
    path('roles/<int:pk>/delete/', views.role_delete, name='role_delete'),
    
    # User Role Management URLs
    path('user-roles/', views.user_role_list, name='user_role_list'),
    path('user-roles/create/', views.user_role_create, name='user_role_create'),
    path('user-roles/<int:pk>/edit/', views.user_role_edit, name='user_role_edit'),
    path('user-roles/<int:pk>/delete/', views.user_role_delete, name='user_role_delete'),
] 