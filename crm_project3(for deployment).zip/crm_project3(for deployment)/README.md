# EdTech CRM System

A Customer Relationship Management (CRM) system for educational technology companies to manage university leads, contacts, accounts, and opportunities.

## Features

- User authentication (login/logout)
- University leads management
- University contacts management
- University accounts management
- University opportunities management
- Data import/export using Pandas

## Setup Instructions

1. Clone the repository
2. Create a virtual environment:
   ```
   python -m venv venv
   ```
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`
4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
5. Create a `.env` file in the project root with the following variables:
   ```
   DEBUG=True
   SECRET_KEY=your_secret_key
   DB_NAME=your_db_name
   DB_USER=your_db_user
   DB_PASSWORD=your_db_password
   DB_HOST=localhost
   DB_PORT=3306
   ```
6. Run migrations:
   ```
   python manage.py makemigrations
   python manage.py migrate
   ```
7. Create a superuser:
   ```
   python manage.py createsuperuser
   ```
8. Run the development server:
   ```
   python manage.py runserver
   ```

## Project Structure

- `crm_project/` - Main project directory
  - `edtech_crm/` - Main Django app
  - `users/` - User authentication app
  - `templates/` - HTML templates
  - `static/` - Static files (CSS, JS, images) 