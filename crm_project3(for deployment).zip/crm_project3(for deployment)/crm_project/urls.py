"""
URL configuration for crm_project project.
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from django.contrib.auth.decorators import login_required

urlpatterns = [
    # Make login page the default landing page
    path('', RedirectView.as_view(url='/users/login/', permanent=False)),
    
    # Include CRM URLs with a different base path
    path('dashboard/', RedirectView.as_view(url='/crm/', permanent=False)),
    path('crm/', include('edtech_crm.urls')),
    
    # Admin and user authentication URLs
    path('admin/', admin.site.urls),
    path('users/', include('users.urls')),
] 